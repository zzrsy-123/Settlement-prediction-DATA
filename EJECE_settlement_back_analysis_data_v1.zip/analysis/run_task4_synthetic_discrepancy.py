"""Task 4: model-discrepancy synthetic test in MEAN Terzaghi settlement.

Unlike the legacy same-family generate/invert checks, the truth here contains
effects the inversion does NOT model: wrong drainage length, wrong
single/double-drainage boundary, omitted secondary (log) settlement, and a
delayed second loading stage handled by linear superposition.

Final numerical design (following the preserved weak-information pilot):
- Layer thickness H = 3 m, settlement in metres, time in days.
- Truth cv_true = 4.0 m^2/year (= cv_day = 4.0/365 m^2/day), chosen so the
  fit window reaches Tv ~ 0.29 and the 730 d record reaches Tv ~ 0.89; with a
  slower cv the entire early window stays in the sqrt(Tv) regime, where rate
  and amplitude are nearly confounded (pilot in qa/initial_synthetic/).
- Average degree U(Tv), Tv = cv_day * t / H_dr^2; single drainage H_dr = H,
  double drainage H_dr = H/2 (same series, different drainage path).
- Truth settlement: s(t) = S_inf * U(t) [+ secondary/superposition terms].
- Inversion: s(t) = A * U_fit(t; cv_hat, assumed H_dr), A >= 0 fitted (NNLS,
  closed-form profile over a rate grid); cv_hat in m^2/year is
  alpha_hat * H_dr_assumed^2 * 365.
- Observation times (irregular, days after loading):
  7, 14, 30, 60, 90, 120, 180, 240, 365, 500, 730.
- Early-fit window: t <= 240 d (8 points); late response: t > 240 d (365, 500,
  730 d, 3 points). The initial pilot (H = 5 m, cv = 1.2 m^2/yr, cutoff 180 d)
  kept the whole window in the sqrt(Tv) regime where rate and amplitude are
  nearly confounded, so its matched case could NOT recover the rate; that
  pilot is preserved in qa/initial_synthetic/ and is reported as a
  short-window weak-identification result, not an implementation failure.
- Noise: iid N(0, 5 mm) on settlement, 29 noisy realizations + 1 noise-free
  reference per setting, seed 20260929. The SAME noise vector is used across
  settings for each realization index (common random numbers), so the exact
  same-truth mappings (x1.44 / x0.64 / x0.25) can be checked per realization
  against the matched fit; the double-drainage truth has an exact x4.00
  noise-free mapping. Known truth amplitudes S_inf = 1.0 m;
  fitted amplitude free. The exact truth rates are included in the grid.

Note: mean settlement depends on cv and H_dr only through cv/H_dr^2, so the
drainage-length error is EXACTLY confounded with cv in the response (this
geometric confounding is exact; the early-time sqrt(Tv) rate-amplitude
degeneracy is an asymptotic approximation for finite Tv). The test quantifies
the resulting cv bias rather than pretending to separate them. Synthetic
discrepancy is not field validation.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd

import revision_core as rc

H_M = 3.0
CV_TRUE_M2_YR = 4.0
CV_DAY = CV_TRUE_M2_YR / 365.0
S_INF_M = 1.0
T_OBS = np.array([7, 14, 30, 60, 90, 120, 180, 240, 365, 500, 730], dtype=float)
T_FIT_MAX = 240.0
SIGMA_NOISE_M = 0.005
N_REAL = 30
SEED = 20260929
# alpha grid includes the exact truth rates (single and double drainage)
ALPHA_GRID = np.sort(np.concatenate([
    np.geomspace(1.0e-6, 1.0e-1, 2001),
    [CV_DAY / H_M**2, CV_DAY / (H_M / 2) ** 2],
]))  # Tv/day at the ASSUMED drainage path
SECONDARY_B_M = 0.15
SECONDARY_TREF_D = 100.0
LOAD2_TIME_D = 120.0
LOAD1_S_M, LOAD2_S_M = 0.7, 0.5


def u_series(alpha, t):
    """U over (len(alpha), len(t)); Tv = alpha * t with alpha = cv_day/H_dr^2."""
    return rc.terzaghi_average_degree(np.asarray(alpha)[:, None] * np.asarray(t)[None, :])


def truth_signal(setting, t):
    u_single = u_series(np.array([CV_DAY / H_M**2]), t)[0]          # single drainage
    u_double = u_series(np.array([CV_DAY / (H_M / 2) ** 2]), t)[0]  # double drainage
    if setting in ("matched", "de_plus20", "de_minus20", "boundary_truth_single"):
        return S_INF_M * u_single
    if setting == "boundary_truth_double":
        return S_INF_M * u_double
    if setting == "omitted_secondary":
        return S_INF_M * u_single + SECONDARY_B_M * np.log1p(t / SECONDARY_TREF_D)
    if setting == "delayed_loading":
        s = LOAD1_S_M * u_single.copy()
        late = t > LOAD2_TIME_D
        s[late] += LOAD2_S_M * u_series(np.array([CV_DAY / H_M**2]), t[late] - LOAD2_TIME_D)[0]
        return s
    raise ValueError(setting)


SETTINGS = {
    # setting: (assumed H_dr in the inversion, what is wrong)
    "matched": (H_M, "none; sanity recovery"),
    "de_plus20": (1.2 * H_M, "inversion drainage path +20% (cv confounded, expect cv_hat ~ 1.44x)"),
    "de_minus20": (0.8 * H_M, "inversion drainage path -20% (expect cv_hat ~ 0.64x)"),
    "boundary_truth_single": (H_M / 2, "truth single drainage, inversion assumes double"),
    "boundary_truth_double": (H_M, "truth double drainage, inversion assumes single"),
    "omitted_secondary": (H_M, "truth has log-time secondary settlement, inversion primary-only"),
    "delayed_loading": (H_M, "truth has a 2nd load at 120 d (superposition), inversion single instant load"),
}


def main():
    rc.RESULTS.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    fit_mask = T_OBS <= T_FIT_MAX
    n_fit, n_late = int(fit_mask.sum()), int((~fit_mask).sum())
    rows = []
    # Tv = alpha*t with alpha already containing the assumed H_dr, so one
    # response matrix serves all settings; h_dr only converts alpha -> cv.
    u_fit = u_series(ALPHA_GRID, T_OBS)
    # Common random numbers: one noise bank shared across all settings.
    noise_bank = rng.normal(0.0, SIGMA_NOISE_M, (N_REAL, T_OBS.size))
    noise_bank[0] = 0.0  # realization 0 = noise-free structural reference
    for real in range(N_REAL):
        for setting, (h_dr, _) in SETTINGS.items():
            clean = truth_signal(setting, T_OBS)
            noise = noise_bank[real]
            y = clean + noise
            a, sse = rc.profile_nnls_1col(u_fit[:, fit_mask].T, y[fit_mask])
            i = int(np.argmin(sse))
            numerical_scale = max(float(y[fit_mask] @ y[fit_mask]), 1e-12)
            low_rate_plateau = float(sse[0] - sse[i]) <= 1e-10 * numerical_scale
            alpha_hat = float(ALPHA_GRID[i])
            cv_hat = alpha_hat * h_dr**2 * 365.0
            pred = a[i] * u_fit[i]
            late_err = pred[~fit_mask] - y[~fit_mask]
            clean_late_err = pred[~fit_mask] - clean[~fit_mask]
            rows.append({
                "setting": setting, "realization": real, "noise_free": real == 0,
                "assumed_h_dr_m": h_dr,
                "alpha_hat_tv_per_day": alpha_hat,
                "cv_hat_m2_yr": cv_hat,
                "cv_ratio_hat_over_true": cv_hat / CV_TRUE_M2_YR,
                "amplitude_hat_m": float(a[i]),
                "early_rmse_m": float(np.sqrt(np.mean((pred[fit_mask] - y[fit_mask]) ** 2))),
                "late_rmse_m": float(np.sqrt(np.mean(late_err**2))),
                "late_mean_signed_error_m": float(np.mean(late_err)),
                "late_mean_signed_error_vs_clean_m": float(np.mean(clean_late_err)),
                "final_day730_error_m": float(pred[-1] - y[-1]),
                "rate_at_grid_low_bound": i == 0,
                "rate_at_grid_high_bound": i == ALPHA_GRID.size - 1,
                "low_rate_objective_gap_m2": float(sse[0] - sse[i]),
                "unresolved_low_rate_plateau": low_rate_plateau,
            })
    df = pd.DataFrame(rows)
    df.to_csv(rc.RESULTS / "synthetic_discrepancy_realizations.csv", index=False)
    summ = df[df["realization"] > 0].groupby("setting").agg(
        cv_ratio_median=("cv_ratio_hat_over_true", "median"),
        cv_ratio_q25=("cv_ratio_hat_over_true", lambda s: float(s.quantile(0.25))),
        cv_ratio_q75=("cv_ratio_hat_over_true", lambda s: float(s.quantile(0.75))),
        late_rmse_median_m=("late_rmse_m", "median"),
        late_signed_bias_median_m=("late_mean_signed_error_m", "median"),
        final_error_median_m=("final_day730_error_m", "median"),
        n_grid_low_hits=("rate_at_grid_low_bound", "sum"),
        n_grid_high_hits=("rate_at_grid_high_bound", "sum"),
        n_low_rate_plateau=("unresolved_low_rate_plateau", "sum"),
    ).reset_index()
    nf = df[df["noise_free"]][["setting", "cv_ratio_hat_over_true", "late_rmse_m",
                               "late_mean_signed_error_vs_clean_m", "amplitude_hat_m"]].rename(columns={
        "cv_ratio_hat_over_true": "cv_ratio_noise_free",
        "late_rmse_m": "late_rmse_noise_free_m",
        "late_mean_signed_error_vs_clean_m": "late_structural_bias_m",
        "amplitude_hat_m": "amplitude_noise_free_m"})
    summ = summ.merge(nf, on="setting")
    summ.to_csv(rc.RESULTS / "synthetic_discrepancy_summary.csv", index=False)
    spec = {
        "units": "settlement m, time day, cv m^2/year; H = 3 m; cv_true = 4.0 m^2/year",
        "truth_equation": "s(t) = S_inf U(cv_day t / H_dr^2) (+ setting-specific terms)",
        "inversion_equation": "s(t) = A U(cv_hat_day t / H_dr_assumed^2), A >= 0 NNLS-profiled",
        "observation_times_day": T_OBS.tolist(),
        "fit_window": {"rule": "t <= 240 d", "n_fit_points": n_fit,
                       "n_late_points": n_late, "late_days": [365, 500, 730]},
        "loading": {"delayed_loading": {"load1": [0.7, "m @ t=0"], "load2": [0.5, "m @ t=120 d"],
                                        "superposition": "linear in U"}},
        "secondary": {"b_m": SECONDARY_B_M, "form": "b*log1p(t/100d)"},
        "noise": {"sigma_m": SIGMA_NOISE_M, "n_noisy_realizations": N_REAL - 1,
                  "n_noise_free": 1, "seed": SEED,
                  "pairing": "common random numbers across settings per realization index",
                  "aggregation": "noisy realizations and noise-free reference reported separately"},
        "alpha_grid": {"type": "geomspace(1e-6, 1e-1, 2001) + exact truth rates",
                       "n": int(ALPHA_GRID.size),
                       "truth_rate_single": float(CV_DAY / H_M**2),
                       "truth_rate_double": float(CV_DAY / (H_M / 2) ** 2)},
        "confounding": ("mean settlement identifies only cv/H_dr^2; drainage-length "
                        "errors map exactly into cv bias (x1.44 / x0.64 for +/-20%)"),
        "settings": {k: v[1] for k, v in SETTINGS.items()},
        "boundary": "synthetic model discrepancy; NOT field validation",
    }
    (rc.RESULTS / "synthetic_specification.json").write_text(json.dumps(spec, indent=2))
    print(summ.to_string(index=False))


if __name__ == "__main__":
    main()
