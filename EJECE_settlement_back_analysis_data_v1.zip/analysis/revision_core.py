"""Shared numerics for the post-review Ballina/Haarajoki revision stage.

All calculations here are POST-REVIEW RETROSPECTIVE comparisons under
explicitly FIXED, assumed error scenarios. They are not new independent
validation, and delta-chi-square support intervals are approximate
conditional likelihood-ratio diagnostics, not validated coverage.

Reuse: legacy forward functions/data are imported where possible
(`run_ballina_v14` loader, K_GRID, geometry, k_to_cr_year). The Terzaghi
average-degree series follows `run_inverse_v14.terzaghi_average_degree`,
with increased truncation and explicit zero-time handling for new analyses.
The old 60-term response is retained only to diagnose truncation effects;
the full Haarajoki module requires an unavailable image-reading dependency.
"""
from __future__ import annotations

import math
import os
import sys
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mplconfig_k3_revision")

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "analysis" / "results"
FIGURES = ROOT / "analysis" / "figures"

# --- Ballina data (Huang et al. 2021 workbook, Fig. 3 / Fig. 10) -------------
T0_DAY = 58.0  # shared settlement anchor, days
TEST_START_DAY = 215.0  # retrospective cutoff, days
K_GRID = np.geomspace(1.0e-4, 1.0, 6001)
D_CELL_M = 1.354
D_DRAIN_M = 0.050


def load_ballina():
    """Return (day, settlement_m, anchor settlement s0, Fig.10 frame)."""
    monitoring = pd.read_csv(ROOT / 'data/ballina/monitoring_observations.csv')
    fig10 = pd.read_csv(ROOT / 'data/ballina/published_forecast_comparison.csv')
    day = monitoring["day"].to_numpy(float)
    settlement = monitoring["settlement_m"].to_numpy(float)
    s0 = float(monitoring.loc[monitoring["day"] == T0_DAY, "settlement_m"].iloc[0])
    return day, settlement, s0, fig10


def ballina_train_later(day, cutoff=TEST_START_DAY):
    """Training increments: anchor < day <= cutoff. Later observations: day > cutoff."""
    return (day > T0_DAY) & (day <= cutoff), day > cutoff


# --- Long-term model forms (vary ONLY the long-term functional form) ---------
# increment(dt) = a * (1 - exp(-k dt)) + b * g(dt), with a, b >= 0 (NNLS).
FORMS = ("primary_only", "log1p", "sqrt", "linear")


def long_term_component(dt: np.ndarray, form: str) -> np.ndarray:
    x = np.maximum(np.asarray(dt, float), 0.0) / T0_DAY
    if form == "log1p":
        return np.log1p(x)
    if form == "sqrt":
        return np.sqrt(1.0 + x) - 1.0
    if form == "linear":
        return x
    raise ValueError(form)


def design_columns(dt: np.ndarray, k_grid: np.ndarray, form: str):
    """Return (X1, X2): primary column (n, G) and long-term column (n,) or None."""
    dt = np.asarray(dt, dtype=float)
    primary = 1.0 - np.exp(-np.maximum(dt, 0.0)[:, None] * np.asarray(k_grid)[None, :])
    if form == "primary_only":
        return primary, None
    return primary, long_term_component(dt, form)


def hyperbolic_column(dt: np.ndarray, h_grid: np.ndarray) -> np.ndarray:
    """Empirical saturating hyperbolic alternative: (dt/58) / (1 + H*dt/58).

    Saturates at 1/H as dt -> infinity; amplitude a >= 0 fitted by NNLS.
    """
    x = np.maximum(np.asarray(dt, float), 0.0) / T0_DAY
    return x[:, None] / (1.0 + np.asarray(h_grid)[None, :] * x[:, None])


# --- Fixed-scenario covariance with the shared subtracted anchor -------------
def absolute_cov(times: np.ndarray, sigma_m: float, ell_day: float) -> np.ndarray:
    """Assumed absolute-observation covariance C_ij = sigma^2 exp(-|ti-tj|/ell)."""
    t = np.asarray(times, dtype=float)
    d = np.abs(t[:, None] - t[None, :])
    corr = np.eye(t.size) if ell_day == 0 else np.exp(-d / ell_day)
    return sigma_m**2 * corr


def increment_cov(times_with_anchor_first: np.ndarray, sigma_m: float, ell_day: float) -> np.ndarray:
    """Covariance of increments y_i = s_i - s_0 sharing the subtracted anchor.

    Cinc(i,j) = C_ij - C_i0 - C_0j + C_00, honouring the actual irregular time
    intervals. The exact-zero anchor increment is NOT an observation; the
    returned matrix covers only the n-1 later increments.
    """
    c = absolute_cov(times_with_anchor_first, sigma_m, ell_day)
    return c[1:, 1:] - c[1:, :1] - c[:1, 1:] + c[0, 0]


def whiten(cov: np.ndarray) -> np.ndarray:
    """Cholesky factor L (cov = L L^T) of a fixed positive-definite covariance."""
    return np.linalg.cholesky(cov)


# --- Vectorized bounded least squares over a rate grid -----------------------
def profile_nnls_1col(x: np.ndarray, y: np.ndarray):
    """min ||a x - y||^2 over a >= 0 for x (n, G), y (n). Returns (a (G,), sse (G,))."""
    xx = np.sum(x * x, axis=0)
    xy = np.asarray(x).T @ np.asarray(y)
    a = np.maximum(xy / np.maximum(xx, 1e-300), 0.0)
    sse = np.sum(np.asarray(y) ** 2) - 2.0 * a * xy + a**2 * xx
    return a, np.maximum(sse, 0.0)


def profile_nnls_2col(x1: np.ndarray, x2: np.ndarray, y: np.ndarray):
    """Vectorized 2-column NNLS over a grid.

    x1 (n, G), x2 (n,), y (n,) -> (coef (2, G), sse (G,)) with coef >= 0.
    Closed form: unconstrained solve, else the better of the two active-set
    boundary solutions (one coefficient zero). Verified against scipy NNLS in
    analysis/tests/test_revision.py.
    """
    x2g = np.broadcast_to(np.asarray(x2)[:, None], np.asarray(x1).shape)
    yv = np.asarray(y, dtype=float)
    g11 = np.sum(x1 * x1, axis=0)
    g22 = float(np.sum(x2g[:, 0] ** 2))
    g12 = np.sum(x1 * x2g, axis=0)
    b1 = np.asarray(x1).T @ yv
    b2 = float(np.sum(x2g[:, 0] * yv))
    det = g11 * g22 - g12**2
    det = np.where(np.abs(det) < 1e-300, np.nan, det)
    a1 = (g22 * b1 - g12 * b2) / det
    a2 = (g11 * b2 - g12 * b1) / det
    yty = float(np.sum(yv**2))

    def sse_of(c1, c2):
        return yty - 2.0 * (c1 * b1 + c2 * b2) + c1**2 * g11 + 2.0 * c1 * c2 * g12 + c2**2 * g22

    sse_u = sse_of(a1, a2)
    ok_u = (a1 >= 0.0) & (a2 >= 0.0)
    # Boundary: a2 = 0
    c1 = np.maximum(b1 / np.maximum(g11, 1e-300), 0.0)
    sse_b1 = sse_of(c1, 0.0)
    # Boundary: a1 = 0
    c2 = np.full(np.asarray(x1).shape[1], max(b2 / max(g22, 1e-300), 0.0))
    sse_b2 = sse_of(0.0, c2)

    coef1 = np.where(ok_u, a1, np.where(sse_b1 <= sse_b2, c1, 0.0))
    coef2 = np.where(ok_u, a2, np.where(sse_b1 <= sse_b2, 0.0, c2))
    sse = np.where(ok_u, sse_u, np.minimum(sse_b1, sse_b2))
    return np.vstack([coef1, coef2]), np.maximum(sse, 0.0)


# --- Conditional support interval --------------------------------------------
def support_interval(grid: np.ndarray, chi2: np.ndarray, delta: float = 3.841):
    """Approximate conditional 95% likelihood-ratio SUPPORT interval.

    Returns dict with best value, interval bounds, and truncation flags.
    delta = 3.841 (chi2_1, 0.95). This is NOT validated coverage: fixed assumed
    covariance, profiled amplitudes, very small samples.
    """
    grid = np.asarray(grid, float)
    chi2 = np.asarray(chi2, float)
    i = int(np.nanargmin(chi2))
    inside = chi2 <= chi2[i] + delta
    lo, hi = grid[inside].min(), grid[inside].max()
    return {
        "best": float(grid[i]),
        "chi2_min": float(chi2[i]),
        "lo": float(lo),
        "hi": float(hi),
        "ratio_hi_lo": float(hi / lo) if lo > 0 else float("inf"),
        "truncated_at_grid_low": bool(inside[0]),
        "truncated_at_grid_high": bool(inside[-1]),
        "n_grid_inside": int(inside.sum()),
    }


def lag1_correlation(residuals: np.ndarray):
    """Descriptive lag-one residual correlation (n reported; irregular-time
    caution: successive residuals are NOT equally spaced, so this is a rough
    descriptive statistic, not an estimated valid noise process)."""
    r = np.asarray(residuals, float)
    n = r.size - 1
    if n < 2 or np.std(r[:-1]) == 0 or np.std(r[1:]) == 0:
        return float("nan"), n
    return float(np.corrcoef(r[:-1], r[1:])[0, 1]), n


# --- Terzaghi solutions (legacy lineage, new-series convergence tested) ------
def terzaghi_average_degree(tv: np.ndarray, n_terms: int = 500) -> np.ndarray:
    """Average consolidation with drainage path H_dr; double drainage uses H/2."""
    return terzaghi_u_series(tv, n_terms)


def terzaghi_response(rate_day, elapsed_day) -> np.ndarray:
    """Legacy truncation diagnostic only; copied from legacy
    run_haarajoki_frozen_v18.terzaghi_response (60 terms). rate_day is the
    time factor rate in Tv per day, i.e. cv/H_dr^2 in day^-1."""
    rate = np.asarray(rate_day, dtype=float)
    time = np.maximum(np.asarray(elapsed_day, dtype=float), 0.0)
    scalar_rate = rate.ndim == 0
    scalar_time = time.ndim == 0
    rate = np.atleast_1d(rate)[:, None]
    time = np.atleast_1d(time)[None, :]
    degree = np.arange(60, dtype=float)
    odd = 2.0 * degree + 1.0
    coefficient = 8.0 / (math.pi**2 * odd**2)
    exponent = -(math.pi**2 / 4.0) * odd[:, None, None] ** 2 * rate[None, :, :] * time[None, :, :]
    response = 1.0 - np.sum(coefficient[:, None, None] * np.exp(exponent), axis=0)
    if scalar_rate and scalar_time:
        return np.asarray(response[0, 0])
    if scalar_rate:
        return response[0]
    if scalar_time:
        return response[:, 0]
    return response


def terzaghi_u_series(tv: np.ndarray, n_terms: int = 500) -> np.ndarray:
    """Average-degree series, checked at 500/1000 terms on the analysis grids.

    Zero/pre-loading times are evaluated explicitly. Positive times retain
    the original series without subtracting its zero-time truncation tail.
    Smaller positive time factors require a separate truncation check.
    """
    tv = np.asarray(tv, dtype=float)
    time = np.maximum(tv, 0.0)
    residual = np.zeros_like(time)
    for n in range(n_terms):
        odd = 2 * n + 1
        residual += 8.0 / (math.pi**2 * odd**2) * np.exp(-math.pi**2 * odd**2 * time / 4.0)
    return np.where(tv > 0.0, 1.0 - residual, 0.0)


# --- Haarajoki natural-ground centreline data --------------------------------
HAARAJOKI_CSV = ROOT / "data" / "haarajoki" / "digitized_settlement.csv"


def load_haarajoki_centreline(section: str = "natural", calibration_only: bool = True):
    """Centreline only. The three instrument lines are NOT proven independent
    replicates; the new conditional diagnostic therefore uses the centreline
    series alone. Corrected three-line descriptive fits are computed separately
    by haarajoki_corrected.py using the same converged forward response.
    Returns elapsed days (incl. anchor 0) and increments in mm."""
    df = pd.read_csv(HAARAJOKI_CSV)
    sel = df[(df["section"] == section) & (df["sensor"] == "centreline")].sort_values("analysis_index")
    if calibration_only:
        sel = sel[sel["split"] == "calibration_24m"]
    return (
        sel["elapsed_day_from_anchor"].to_numpy(float),
        sel["increment_mm"].to_numpy(float),
        sel,
    )
