"""Tasks 2+3: conditional likelihood/profile analysis and joint contour.

Replaces the arbitrary 1.05*RMSE ratio with an explicitly CONDITIONAL
profile analysis under FIXED error scenarios (assumed, not estimated):
- Ballina: sigma = 5/10/20 mm, correlation length ell = 0/30/90 d.
- Haarajoki natural ground (centreline only): sigma = 3/6 mm, ell = 0/120 d.

Covariance honours the irregular observation intervals and the shared
subtracted anchor via Cinc(i,j) = C_ij - C_i0 - C_0j + C_00. Increments are
NOT treated as independent; the exact-zero anchor is NOT counted as an
observation. With the fixed PD covariance, data/design are whitened and NNLS
amplitudes profiled over rates. delta chi2 = 3.841 is reported as an
approximate conditional 95% likelihood-ratio SUPPORT interval -- NOT
validated coverage (fixed assumed covariance, profiled amplitudes, tiny
samples). Active bounds and grid-truncated intervals are flagged.

Haarajoki's three instrument lines are not proven independent replicates;
this diagnostic uses the centreline only. Legacy three-line point estimates
stay as published and are not re-analysed here.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from scipy.stats import chi2 as chi2_dist

import revision_core as rc

BALLINA_SIGMAS_MM = (5.0, 10.0, 20.0)
BALLINA_ELLS_D = (0.0, 30.0, 90.0)
HAARAJOKI_SIGMAS_MM = (3.0, 6.0)   # 3 mm = legacy digitization jitter scale; 6 mm conservative
HAARAJOKI_ELLS_D = (0.0, 120.0)    # 120 d ~ typical gap between later readings
HAARAJOKI_RATE_GRID = np.geomspace(1.0e-6, 1.0e-1, 4001)  # legacy grid
DELTA = 3.841
DELTA_2PAR = 5.991  # chi2_2, 0.95: two-parameter LR reference for the joint contour


def whitened_profile(times, y, form, k_grid, sigma_m, ell_d):
    """chi2(k) with NNLS amplitudes profiled in whitened space."""
    cov = rc.increment_cov(times, sigma_m, ell_d)
    fac = rc.whiten(cov)
    yw = np.linalg.solve(fac, y)
    x1, x2 = rc.design_columns(times[1:] - times[0], k_grid, form)
    x1w = np.linalg.solve(fac, x1)
    if x2 is None:
        a, chi2 = rc.profile_nnls_1col(x1w, yw)
        coefs = a[None, :]
    else:
        x2w = np.linalg.solve(fac, x2)
        coefs, chi2 = rc.profile_nnls_2col(x1w, x2w, yw)
    return coefs, chi2


def ballina_conditional():
    day, settlement, s0, _ = rc.load_ballina()
    train, _ = rc.ballina_train_later(day)
    times = np.concatenate([[rc.T0_DAY], day[train]])
    y = (settlement[train] - s0)
    rows, profiles = [], []
    lag1_rows = []
    for form in ("primary_only", "log1p"):
        for sigma_mm in BALLINA_SIGMAS_MM:
            for ell in BALLINA_ELLS_D:
                sigma_m = sigma_mm / 1000.0
                coefs, chi2 = whitened_profile(times, y, form, rc.K_GRID, sigma_m, ell)
                sup = rc.support_interval(rc.K_GRID, chi2, DELTA)
                i = int(np.argmin(chi2))
                coef = coefs[:, i]
                # residuals of the best fit (unwhitened, metres) for lag-1 diagnostic
                x1, x2 = rc.design_columns(times[1:] - rc.T0_DAY, rc.K_GRID[i:i+1], form)
                fit = coef[0] * x1[:, 0] + (coef[1] * x2 if x2 is not None else 0.0)
                lag1, n_lag = rc.lag1_correlation(y - fit)
                n_par = 3 if form == "log1p" else 2  # amplitudes + profiled rate
                dof = int(y.size) - n_par
                rows.append({
                    "case": "ballina", "model": form,
                    "sigma_mm": sigma_mm, "ell_day": ell,
                    "n_increments": int(y.size),
                    "residual_dof": dof,
                    "chi2_per_dof": sup["chi2_min"] / max(dof, 1),
                    "chi2_dof_95": float(chi2_dist.ppf(0.95, max(dof, 1))),
                    "error_model_inconsistent": bool(sup["chi2_min"] > chi2_dist.ppf(0.95, max(dof, 1))),
                    "best_k_day_inverse": sup["best"],
                    "support_lo": sup["lo"], "support_hi": sup["hi"],
                    "ratio_hi_lo": sup["ratio_hi_lo"],
                    "chi2_min": sup["chi2_min"],
                    "amplitude_primary_m": float(coef[0]),
                    "amplitude_longterm_m": float(coef[1]) if coef.size > 1 else 0.0,
                    "truncated_at_grid_low": sup["truncated_at_grid_low"],
                    "truncated_at_grid_high": sup["truncated_at_grid_high"],
                    "longterm_amplitude_at_zero_bound": bool(coef.size > 1 and coef[1] <= 1e-12),
                })
                lag1_rows.append({
                    "case": "ballina", "model": form, "sigma_mm": sigma_mm, "ell_day": ell,
                    "lag1_residual_corr": lag1, "n_pairs": n_lag,
                    "caution": ("descriptive only; successive residuals are irregularly "
                                "spaced, not an estimated valid noise process"),
                })
                if form == "log1p":
                    profiles.append(pd.DataFrame({
                        "case": "ballina", "model": form, "sigma_mm": sigma_mm, "ell_day": ell,
                        "k_day_inverse": rc.K_GRID, "chi2": chi2,
                        "delta_chi2": chi2 - chi2[i],
                    }))
    return pd.DataFrame(rows), pd.concat(profiles, ignore_index=True), pd.DataFrame(lag1_rows)


def haarajoki_conditional():
    elapsed, inc_mm, _ = rc.load_haarajoki_centreline("natural", calibration_only=True)
    times = elapsed  # includes anchor 0
    y_m = inc_mm[1:] / 1000.0
    # Converged 500-term series with U(0)=0 enforced; the legacy 60-term
    # truncation created a false low-rate profile bound (parent audit P1).
    resp = rc.terzaghi_u_series(HAARAJOKI_RATE_GRID[:, None] * times[1:][None, :]).T  # (n, G)
    rows, profiles = [], []
    lag1_rows = []
    for sigma_mm in HAARAJOKI_SIGMAS_MM:
        for ell in HAARAJOKI_ELLS_D:
            sigma_m = sigma_mm / 1000.0
            cov = rc.increment_cov(times, sigma_m, ell)
            fac = rc.whiten(cov)
            yw = np.linalg.solve(fac, y_m)
            xw = np.linalg.solve(fac, resp)
            a, chi2 = rc.profile_nnls_1col(xw, yw)
            sup = rc.support_interval(HAARAJOKI_RATE_GRID, chi2, DELTA)
            i = int(np.argmin(chi2))
            fit = a[i] * resp[:, i]
            lag1, n_lag = rc.lag1_correlation(y_m - fit)
            dof = int(y_m.size) - 2  # amplitude + profiled rate
            rows.append({
                "case": "haarajoki_natural_centreline", "model": "terzaghi_vertical",
                "sigma_mm": sigma_mm, "ell_day": ell,
                "n_increments": int(y_m.size),
                "residual_dof": dof,
                "chi2_per_dof": sup["chi2_min"] / max(dof, 1),
                "chi2_dof_95": float(chi2_dist.ppf(0.95, max(dof, 1))),
                "error_model_inconsistent": bool(sup["chi2_min"] > chi2_dist.ppf(0.95, max(dof, 1))),
                "best_k_day_inverse": sup["best"],
                "support_lo": sup["lo"], "support_hi": sup["hi"],
                "ratio_hi_lo": sup["ratio_hi_lo"],
                "chi2_min": sup["chi2_min"],
                "amplitude_primary_m": float(a[i]),
                "amplitude_longterm_m": 0.0,
                "truncated_at_grid_low": sup["truncated_at_grid_low"],
                "truncated_at_grid_high": sup["truncated_at_grid_high"],
                "longterm_amplitude_at_zero_bound": False,
            })
            lag1_rows.append({
                "case": "haarajoki_natural_centreline", "model": "terzaghi_vertical",
                "sigma_mm": sigma_mm, "ell_day": ell,
                "lag1_residual_corr": lag1, "n_pairs": n_lag,
                "caution": ("descriptive only; successive residuals are irregularly "
                            "spaced, not an estimated valid noise process"),
            })
            profiles.append(pd.DataFrame({
                "case": "haarajoki_natural_centreline", "model": "terzaghi_vertical",
                "sigma_mm": sigma_mm, "ell_day": ell,
                "k_day_inverse": HAARAJOKI_RATE_GRID, "chi2": chi2,
                "delta_chi2": chi2 - chi2[i],
            }))
    return pd.DataFrame(rows), pd.concat(profiles, ignore_index=True), pd.DataFrame(lag1_rows)


def joint_contour():
    """Task 3: joint (k, primary amplitude) objective, secondary (log-term)
    amplitude profiled, ONE fixed covariance scenario (sigma=10 mm, ell=30 d).
    Shows how the wide rate support is obscured by fitted-amplitude
    compensation. Noise assumptions are fixed and labelled, not estimated."""
    sigma_mm, ell = 10.0, 30.0
    day, settlement, s0, _ = rc.load_ballina()
    train, _ = rc.ballina_train_later(day)
    times = np.concatenate([[rc.T0_DAY], day[train]])
    y = settlement[train] - s0
    cov = rc.increment_cov(times, sigma_mm / 1000.0, ell)
    fac = rc.whiten(cov)
    yw = np.linalg.solve(fac, y)
    k_grid = np.geomspace(5.0e-3, 3.0e-1, 241)
    a_grid = np.geomspace(2.0e-2, 1.0, 241)
    x1, x2 = rc.design_columns(times[1:] - rc.T0_DAY, k_grid, "log1p")
    x1w = np.linalg.solve(fac, x1)            # (n, G)
    x2w = np.linalg.solve(fac, x2)            # (n,)
    x2x2 = float(x2w @ x2w)
    chi2 = np.empty((a_grid.size, k_grid.size))
    b_prof = np.empty_like(chi2)
    for j, a in enumerate(a_grid):
        r = yw[:, None] - a * x1w              # (n, G)
        b = np.maximum((x2w @ r) / x2x2, 0.0)  # (G,)
        resid = r - b[None, :] * x2w[:, None]
        chi2[j] = np.sum(resid**2, axis=0)
        b_prof[j] = b
    i_min = np.unravel_index(int(np.argmin(chi2)), chi2.shape)
    chi2_min = float(chi2[i_min])
    near = chi2 <= chi2_min + DELTA_2PAR  # two-parameter LR reference region
    slice1p = chi2 <= chi2_min + DELTA    # one-parameter objective slice
    lk = np.log(k_grid)[None, :].repeat(a_grid.size, axis=0)[near]
    la = np.log(a_grid)[:, None].repeat(k_grid.size, axis=1)[near]
    ridge_corr = float(np.corrcoef(lk, la)[0, 1]) if lk.size > 2 else float("nan")
    slope = float(np.polyfit(lk, la, 1)[0]) if lk.size > 2 else float("nan")

    grid_df = pd.DataFrame({
        "k_day_inverse": np.broadcast_to(k_grid[None, :], chi2.shape).ravel(),
        "amplitude_primary_m": np.broadcast_to(a_grid[:, None], chi2.shape).ravel(),
        "chi2": chi2.ravel(),
        "delta_chi2": (chi2 - chi2_min).ravel(),
        "profiled_b_longterm_m": b_prof.ravel(),
        "inside_slice_3p841": slice1p.ravel(),
        "inside_region_5p991": near.ravel(),
    })
    grid_df.to_csv(rc.RESULTS / "joint_objective_grid.csv", index=False)
    summary = {
        "scenario": {"sigma_mm": sigma_mm, "ell_day": ell,
                     "label": "fixed assumed covariance, NOT estimated"},
        "k_grid": {"type": "geomspace", "low": 5e-3, "high": 0.3, "n": 241},
        "amplitude_grid_m": {"type": "geomspace", "low": 0.02, "high": 1.0, "n": 241},
        "profiled": "secondary log-term amplitude only (NNLS, >=0)",
        "best": {"k": float(k_grid[i_min[1]]), "amplitude_primary_m": float(a_grid[i_min[0]]),
                 "chi2_min": chi2_min},
        "near_optimal_region_5p991": {
            "n_grid_points": int(near.sum()),
            "logk_loga_correlation": ridge_corr,
            "dloga_dlogk_slope": slope,
            "k_range_inside": [float(k_grid[near.any(axis=0)].min()),
                               float(k_grid[near.any(axis=0)].max())],
            "a_range_inside": [float(a_grid[near.any(axis=1)].min()),
                               float(a_grid[near.any(axis=1)].max())],
            "caution": ("geometric description of the gridded near-optimal region "
                        "(grid-dependent), not a parameter posterior correlation"),
        },
        "slice_3p841": {
            "label": "one-parameter objective slice only, NOT a joint 95% region",
            "n_grid_points": int(slice1p.sum()),
        },
        "interpretation": ("strong negative k-amplitude compensation: the near-optimal "
                           "ridge extends over a wide rate range because the fitted "
                           "primary amplitude (and profiled log amplitude) compensate; "
                           "profiling amplitudes at each rate hides this joint width."),
    }
    (rc.RESULTS / "joint_contour_summary.json").write_text(json.dumps(summary, indent=2))
    return summary


def main():
    rc.RESULTS.mkdir(parents=True, exist_ok=True)
    b_rows, b_prof, b_lag1 = ballina_conditional()
    h_rows, h_prof, h_lag1 = haarajoki_conditional()
    support = pd.concat([b_rows, h_rows], ignore_index=True)
    support.to_csv(rc.RESULTS / "conditional_support_intervals.csv", index=False)
    pd.concat([b_prof, h_prof], ignore_index=True).to_csv(
        rc.RESULTS / "conditional_profiles.csv", index=False)
    pd.concat([b_lag1, h_lag1], ignore_index=True).to_csv(
        rc.RESULTS / "conditional_lag1_residual_correlation.csv", index=False)

    notes = {
        "covariance": ("fixed assumed scenarios; Cinc(i,j)=Cij-Ci0-C0j+C00 with the "
                       "shared subtracted day-58 anchor (Ballina) or day-0 anchor "
                       "(Haarajoki); irregular intervals honoured via |ti-tj|"),
        "support_interval": ("delta chi2 = 3.841 approximate conditional 95% "
                             "likelihood-ratio SUPPORT interval; not validated coverage"),
        "haarajoki_lines": ("centreline only; the three lines are not proven independent "
                            "replicates; legacy three-line point estimates unchanged"),
        "digitization_precision": ("Haarajoki increments derive from digitized pixels; "
                                   "intervals below pixel precision are not meaningful"),
        "error_model_consistency": ("residual_dof, chi2_per_dof and chi2_dof_95 exported per "
                                    "scenario; error_model_inconsistent=True means the fixed "
                                    "assumed error model itself fits poorly (chi2_min above the "
                                    "dof 95% reference) -- narrow conditional support under such "
                                    "scenarios is not credible uncertainty"),
        "haarajoki_series": ("converged 500-term U(Tv) with U(0)=0 enforced; legacy 60-term "
                             "truncation created a false low-rate profile bound (parent audit)"),
    }
    (rc.RESULTS / "conditional_methods_notes.json").write_text(json.dumps(notes, indent=2))

    contour = joint_contour()
    print(support[["case", "model", "sigma_mm", "ell_day", "best_k_day_inverse",
                   "support_lo", "support_hi", "truncated_at_grid_low",
                   "truncated_at_grid_high", "longterm_amplitude_at_zero_bound"]].to_string(index=False))
    print("\nLag-1:\n", pd.concat([b_lag1, h_lag1]).to_string(index=False))
    print("\nJoint contour summary:\n", json.dumps(contour["near_optimal_region_5p991"], indent=2),
          "\nbest:", contour["best"])


if __name__ == "__main__":
    main()
