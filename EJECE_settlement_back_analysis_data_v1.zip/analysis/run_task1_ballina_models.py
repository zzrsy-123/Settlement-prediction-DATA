"""Task 1: Ballina same-window model-form comparison (POST-REVIEW RETROSPECTIVE).

Training: the six informative day-58..215 increments (76, 92, 117, 152, 191,
215 d). Evaluation: the 11 later observations (243..974 d). All five model
forms are fitted ONLY on training observations with NNLS amplitudes (>= 0)
profiled over the legacy rate grid. All comparisons are retrospective
post-review model-form comparisons, NOT new independent validation.

The published day-215 prediction is extracted from workbook Fig. 10 (column
"215d") at matched observation times. It is a PUBLISHED-FORECAST BENCHMARK
(produced by Huang et al. 2021 with their own procedure), not a rerun and not
an equal-information algorithm race.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd

import revision_core as rc

H_GRID = np.geomspace(1.0e-3, 1.0e3, 4001)  # hyperbolic shape grid, recorded
CUTOFFS = (152, 191, 215)


def fit_form(dt_train, y_train, form, k_grid):
    """Profile NNLS over the rate grid. Returns best dict + profile arrays."""
    x1, x2 = rc.design_columns(dt_train, k_grid, form)
    if x2 is None:
        a, sse = rc.profile_nnls_1col(x1, y_train)
        coefs = a[None, :]
    else:
        coefs, sse = rc.profile_nnls_2col(x1, x2, y_train)
    i = int(np.argmin(sse))
    return {
        "grid_value": float(k_grid[i]),
        "grid_index": i,
        "sse": float(sse[i]),
        "coef": coefs[:, i],
        "at_grid_low": i == 0,
        "at_grid_high": i == k_grid.size - 1,
    }


def fit_hyperbolic(dt_train, y_train, h_grid):
    x = rc.hyperbolic_column(dt_train, h_grid)
    a, sse = rc.profile_nnls_1col(x, y_train)
    i = int(np.argmin(sse))
    return {
        "grid_value": float(h_grid[i]),
        "grid_index": i,
        "sse": float(sse[i]),
        "coef": np.array([a[i]]),
        "at_grid_low": i == 0,
        "at_grid_high": i == h_grid.size - 1,
    }


def predict_form(dt, fit, form, k_grid):
    if form == "hyperbolic":
        x = rc.hyperbolic_column(dt, np.array([fit["grid_value"]]))[:, 0]
        return fit["coef"][0] * x
    x1, x2 = rc.design_columns(dt, np.array([fit["grid_value"]]), form)
    x1 = x1[:, 0]
    if x2 is None:
        return fit["coef"][0] * x1
    return fit["coef"][0] * x1 + fit["coef"][1] * x2


def metrics(obs, pred):
    r = pred - obs
    return float(np.sqrt(np.mean(r**2))), float(np.mean(np.abs(r))), float(r[-1])


def main():
    rc.RESULTS.mkdir(parents=True, exist_ok=True)
    day, settlement, s0, fig10 = rc.load_ballina()
    dt_all = day - rc.T0_DAY
    inc_all = settlement - s0
    n_amp = {"primary_only": 1, "hyperbolic": 1, "log1p": 2, "sqrt": 2, "linear": 2}
    models = ("primary_only", "log1p", "sqrt", "linear", "hyperbolic")

    rows, pred_rows = [], []
    for cutoff in CUTOFFS:
        train, later = rc.ballina_train_later(day, cutoff)
        fixed_common = day > rc.TEST_START_DAY  # 243-974 d, same for all cutoffs
        n_train = int(train.sum())
        for form in models:
            n_par = n_amp[form] + 1  # amplitudes + one grid (rate/shape) parameter
            dof = n_train - n_par
            if form == "hyperbolic":
                fit = fit_hyperbolic(dt_all[train], inc_all[train], H_GRID)
            else:
                fit = fit_form(dt_all[train], inc_all[train], form, rc.K_GRID)
            pred_all = predict_form(dt_all, fit, form, rc.K_GRID) + s0
            rmse_l, mae_l, bias_f = metrics(settlement[later], pred_all[later])
            rmse_fc, mae_fc, _ = metrics(settlement[fixed_common], pred_all[fixed_common])
            rmse_t, _, _ = metrics(settlement[train], pred_all[train])
            coef = fit["coef"]
            rows.append({
                "cutoff_day": cutoff,
                "model": form,
                "n_train_increments": n_train,
                "n_fitted_parameters": n_par,
                "residual_dof": dof,
                "information_status": "ok" if dof > 0 else "INSUFFICIENT residual degrees of freedom",
                "grid_parameter": fit["grid_value"],
                "grid_parameter_name": "H_shape" if form == "hyperbolic" else "k_day_inverse",
                "amplitude_primary_m": float(coef[0]),
                "amplitude_longterm_m": float(coef[1]) if coef.size > 1 else 0.0,
                "train_rmse_m": rmse_t,
                "holdout_rmse_m": rmse_l,
                "holdout_mae_m": mae_l,
                "n_later_points": int(later.sum()),
                "fixed_common_243_974_rmse_m": rmse_fc,
                "fixed_common_243_974_mae_m": mae_fc,
                "final_day974_bias_m": float(pred_all[-1] - settlement[-1]),
                "final_day974_prediction_m": float(pred_all[-1]),
                "rate_at_grid_low_bound": fit["at_grid_low"],
                "rate_at_grid_high_bound": fit["at_grid_high"],
                "longterm_amplitude_at_zero_bound": bool(coef.size > 1 and coef[1] <= 1e-12),
            })
            if cutoff == 215:
                for d, p, o, is_tr in zip(day, pred_all, settlement, train):
                    if d >= rc.T0_DAY:
                        split = ("anchor" if d == rc.T0_DAY
                                 else "train" if is_tr else "later_holdout")
                        pred_rows.append({
                            "model": form, "day": float(d),
                            "observed_m": float(o), "prediction_m": float(p),
                            "split": split,
                        })

    results = pd.DataFrame(rows)
    results.to_csv(rc.RESULTS / "ballina_model_comparison.csv", index=False)
    pd.DataFrame(pred_rows).to_csv(rc.RESULTS / "ballina_per_point_predictions.csv", index=False)

    # Published Fig.10 "215d" benchmark at matched later observation times.
    f10_days = fig10["days"].to_numpy(float)
    later_mask = f10_days > rc.TEST_START_DAY
    obs = fig10["measurement"].to_numpy(float)[later_mask]
    pub = fig10["215d"].to_numpy(float)[later_mask]
    rmse_p, mae_p, bias_p = metrics(obs, pub)
    published = pd.DataFrame([{
        "source": "Huang2021_Fig10_215d_published_forecast",
        "n_later_points": int(later_mask.sum()),
        "holdout_rmse_m": rmse_p, "holdout_mae_m": mae_p,
        "final_day974_bias_m": bias_p,
        "note": ("Published forecast extracted from workbook Fig.10 at matched "
                 "observation times; a published-forecast benchmark, not a rerun "
                 "and not an equal-information algorithm race."),
    }])
    published.to_csv(rc.RESULTS / "ballina_published_fig10_benchmark.csv", index=False)
    matched = pd.DataFrame({
        "day": f10_days[later_mask], "observed_m": obs, "published_215d_m": pub,
    })
    matched.to_csv(rc.RESULTS / "ballina_published_fig10_matched_points.csv", index=False)

    grids = {
        "k_grid_day_inverse": {"type": "geomspace", "low": 1.0e-4, "high": 1.0, "n": int(rc.K_GRID.size)},
        "hyperbolic_H_grid": {"type": "geomspace", "low": 1.0e-3, "high": 1.0e3, "n": int(H_GRID.size)},
        "amplitude_bounds": "NNLS nonnegativity only (no explicit upper bound); zero-bound hits flagged per row",
        "anchor": "day 58 settlement subtracted; increments fitted, anchor not counted as observation",
        "status": "ALL comparisons are post-review retrospective model-form comparisons, not new independent validation",
    }
    (rc.RESULTS / "ballina_grids_and_bounds.json").write_text(json.dumps(grids, indent=2))

    show = results[results["cutoff_day"] == 215]
    print(show[["model", "grid_parameter", "amplitude_primary_m", "amplitude_longterm_m",
                "train_rmse_m", "holdout_rmse_m", "holdout_mae_m", "final_day974_bias_m"]].to_string(index=False))
    print("\nAll cutoffs:\n", results[["cutoff_day", "model", "residual_dof", "holdout_rmse_m",
                                       "final_day974_bias_m"]].to_string(index=False))
    print("\nPublished benchmark:\n", published.to_string(index=False))


if __name__ == "__main__":
    main()
