"""Corrected Haarajoki three-line refits: converged series and exact U(0)=0.

Corrects the retained numerical error in the legacy three-line branch
(`run_haarajoki_frozen_v18.py`, 60-term Terzaghi series with U(0) > 0) while
keeping the legacy protocol otherwise unchanged: same digitized data, rate
grids, windows, free nonnegative per-sensor amplitudes, unweighted SSE, and
the RMSE denominator that includes the exact-zero anchor.

Corrections relative to legacy:
- vertical response uses revision_core.terzaghi_average_degree (500 terms,
  U(0)=0 enforced, no zero-time series-tail subtraction at positive times);
- numerically flat minima are handled by an explicit plateau rule: the
  selected candidate is the smallest grid rate whose SSE is within
  1e-10 * sum(observed**2) of the minimum SSE; the strict argmin is retained
  as a diagnostic only; plateau and grid-bound hits are flagged and boundary
  values are never reported as identified;
- 500- versus 1000-term agreement is verified on the actual positive grids.

The descriptive "near-optimal" interval keeps the legacy definition (grid
points with RMSE <= 1.05 * minimum RMSE). It is a within-case objective
description, NOT a confidence interval and not a parameter-support statement.
Later-observation metrics (analysis indices 10..14) are common to all windows
and are evaluation only: no later observation influences any fit.

These are corrected retrospective point estimates, not new independent
validation. Geometry conversions are conditional mappings under assumed
idealized geometry, not identified soil coefficients.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D

sys.path.insert(0, str(Path(__file__).resolve().parent))
import revision_core as rc  # noqa: E402

ROOT = rc.ROOT
RESULTS = rc.RESULTS
FIGURES = rc.FIGURES

# --- Legacy protocol constants (unchanged) -----------------------------------
RATE_GRID = np.geomspace(1.0e-6, 1.0e-1, 4001)
JITTER_GRID = np.geomspace(1.0e-6, 1.0e-1, 1201)
WINDOWS = {12: 5, 18: 7, 24: 9}          # window month -> last calibration analysis index
LATER_MIN_INDEX = 10                     # later indices 10..14 shared by all windows
SENSORS = ("left_4m", "centreline", "right_4m")
JITTER_REPEATS = 300
JITTER_SIGMA_MM = 3.0
RNG_SEED = 20260805
DAYS_PER_YEAR = 365.25
N_TERMS = 500

# Plateau rule: candidates with SSE within PLATEAU_RTOL * sum(observed**2)
# of the minimum SSE are numerically indistinguishable; select the smallest.
PLATEAU_RTOL = 1.0e-10
# Descriptive near-optimal interval factor (legacy definition; descriptive only).
NEAR_FACTOR = 1.05

# Idealized PVD geometry (legacy values).
PVD_DE_M = 1.13
PVD_DW_M = 0.067
PVD_N = PVD_DE_M / PVD_DW_M
PVD_F = math.log(PVD_N) - 0.75
DRAINAGE_LENGTHS_M = (11.1, 22.2)

COLORS = {
    "ink": "#24313A",
    "blue": "#2F6F9F",
    "orange": "#D26A2E",
    "green": "#3B7F68",
    "gray": "#7B848A",
}


# --- Data ---------------------------------------------------------------------
def load_data() -> pd.DataFrame:
    """Digitized three-line record in original file order (RNG pairing depends on it)."""
    return pd.read_csv(rc.HAARAJOKI_CSV)


def window_frame(data: pd.DataFrame, section: str, cutoff_index: int) -> pd.DataFrame:
    """Calibration rows only: one section, analysis_index <= cutoff_index."""
    return data.loc[(data["section"] == section) & (data["analysis_index"] <= cutoff_index)]


def section_matrix(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """(elapsed days (Nt,), increments mm (3, Nt)); legacy pivot, includes anchor."""
    pivot = frame.pivot(index="elapsed_day_from_anchor", columns="sensor", values="increment_mm")
    pivot = pivot.loc[:, list(SENSORS)].sort_index()
    return pivot.index.to_numpy(float), pivot.to_numpy(float).T


# --- Responses (corrected series; U(0)=0 exact) --------------------------------
def natural_response(rate_grid: np.ndarray, time: np.ndarray, n_terms: int = N_TERMS) -> np.ndarray:
    """Terzaghi average degree U(rate * t) on (n_grid, n_time); U(0)=0 exactly."""
    tv = np.asarray(rate_grid, dtype=float)[:, None] * np.asarray(time, dtype=float)[None, :]
    return rc.terzaghi_average_degree(tv, n_terms=n_terms)


def radial_response(rate_grid: np.ndarray, time: np.ndarray) -> np.ndarray:
    """Ideal radial response 1 - exp(-rate * t); exact and U(0)=0."""
    rate = np.asarray(rate_grid, dtype=float)[:, None]
    t = np.maximum(np.asarray(time, dtype=float), 0.0)[None, :]
    return 1.0 - np.exp(-rate * t)


def combined_response(
    rate_grid: np.ndarray, time: np.ndarray, vertical_rate_day: float, n_terms: int = N_TERMS
) -> np.ndarray:
    """Carrillo combination 1 - (1-U_v)(1-U_r) with the corrected vertical series."""
    vertical = natural_response(
        np.array([float(vertical_rate_day)]), np.asarray(time, dtype=float), n_terms=n_terms
    )[0]
    radial = radial_response(rate_grid, time)
    return 1.0 - (1.0 - vertical[None, :]) * (1.0 - radial)


# --- Corrected shared-rate fit ---------------------------------------------------
def _plateau_selection(sse: np.ndarray, tolerance_mm2: float) -> dict:
    """Smallest-rate candidate within tolerance of min SSE; strict argmin kept."""
    strict = int(np.argmin(sse))
    plateau = sse <= sse[strict] + tolerance_mm2
    selected = int(np.flatnonzero(plateau)[0])
    return {
        "strict_index": strict,
        "selected_index": selected,
        "plateau_mask": plateau,
        "n_plateau_candidates": int(plateau.sum()),
    }


def _identification_flag(selected: int, n_grid: int, n_plateau: int) -> str:
    if selected == 0:
        return "at_grid_low_bound_not_identified"
    if selected == n_grid - 1:
        return "at_grid_high_bound_not_identified"
    if n_plateau > 1:
        return "numerically_tied_grid_candidates"
    return "interior_minimum"


def fit_shared_rate(
    frame: pd.DataFrame,
    rate_grid: np.ndarray,
    response_matrix: np.ndarray,
    model: str,
    window_month: int,
) -> tuple[dict, pd.DataFrame]:
    """Legacy profiled-amplitude fit with corrected plateau/bound handling.

    Free nonnegative per-sensor amplitudes, simple unweighted SSE, RMSE
    denominator 3*Nt including the exact-zero anchor (legacy definition).
    """
    time, observed = section_matrix(frame)
    if response_matrix.shape != (rate_grid.size, time.size):
        raise ValueError(f"Response shape {response_matrix.shape} does not match grid/time.")
    denominator = np.sum(response_matrix**2, axis=1)
    cross = response_matrix @ observed.T
    amplitudes = np.maximum(cross / np.maximum(denominator, 1e-300)[:, None], 0.0)
    observed_energy = np.sum(observed**2, axis=1)[None, :]
    sse_raw = np.sum(
        observed_energy - 2.0 * amplitudes * cross + amplitudes**2 * denominator[:, None], axis=1
    )
    observed_energy_total = float(np.sum(observed**2))
    tolerance_mm2 = PLATEAU_RTOL * observed_energy_total
    sel = _plateau_selection(sse_raw, tolerance_mm2)
    i_sel = sel["selected_index"]
    sse = np.maximum(sse_raw, 0.0)
    objective = np.sqrt(sse / observed.size)
    near = objective <= NEAR_FACTOR * objective.min()
    result = {
        "model": model,
        "window_month": window_month,
        "n_time_points": int(time.size),
        "n_sensors": int(observed.shape[0]),
        "rate_day_inverse": float(rate_grid[i_sel]),
        "rate_argmin_strict": float(rate_grid[sel["strict_index"]]),
        "sse_selected_mm2": float(sse_raw[i_sel]),
        "sse_min_mm2": float(sse_raw[sel["strict_index"]]),
        "plateau_tolerance_mm2": float(tolerance_mm2),
        "n_plateau_candidates": sel["n_plateau_candidates"],
        "plateau_selected": bool(sel["n_plateau_candidates"] > 1),
        "selected_at_grid_low": bool(i_sel == 0),
        "selected_at_grid_high": bool(i_sel == rate_grid.size - 1),
        "rate_identification": _identification_flag(i_sel, rate_grid.size, sel["n_plateau_candidates"]),
        "near_rate_low": float(rate_grid[near].min()),
        "near_rate_high": float(rate_grid[near].max()),
        "near_rate_ratio": float(rate_grid[near].max() / rate_grid[near].min()),
        "near_truncated_at_grid_low": bool(near[0]),
        "near_truncated_at_grid_high": bool(near[-1]),
        "calibration_rmse_mm": float(objective[i_sel]),
        "amplitudes_mm": {s: float(v) for s, v in zip(SENSORS, amplitudes[i_sel])},
    }
    profile = pd.DataFrame(
        {
            "model": model,
            "window_month": window_month,
            "rate_day_inverse": rate_grid,
            "sse_mm2": sse_raw,
            "objective_rmse_mm": objective,
        }
    )
    return result, profile


def predict_response(model: str, rate: float, time: np.ndarray, vertical_rate_day: float | None = None):
    if model == "natural_vertical":
        return natural_response(np.array([rate]), time)[0]
    if model == "pvd_radial":
        return radial_response(np.array([rate]), time)[0]
    if model == "pvd_combined":
        if vertical_rate_day is None:
            raise ValueError("Combined prediction requires the fixed vertical rate.")
        return combined_response(np.array([rate]), time, vertical_rate_day)[0]
    raise ValueError(model)


def predict_result(result: dict, frame: pd.DataFrame) -> pd.DataFrame:
    """Predictions for every row of frame (all 15 indices); fitted values are fixed."""
    rows: list[dict] = []
    rate = float(result["rate_day_inverse"])
    vertical = result.get("fixed_vertical_rate_day_inverse")
    for sensor in SENSORS:
        sensor_frame = frame.loc[frame["sensor"] == sensor].sort_values("analysis_index")
        time = sensor_frame["elapsed_day_from_anchor"].to_numpy(float)
        response = predict_response(result["model"], rate, time, vertical)
        predicted = float(result["amplitudes_mm"][sensor]) * response
        for (_, source), value in zip(sensor_frame.iterrows(), predicted):
            rows.append(
                {
                    "model": result["model"],
                    "window_month": result["window_month"],
                    "section": source["section"],
                    "sensor": sensor,
                    "analysis_index": int(source["analysis_index"]),
                    "elapsed_day_from_anchor": float(source["elapsed_day_from_anchor"]),
                    "split": source["split"],
                    "observed_increment_mm": float(source["increment_mm"]),
                    "predicted_increment_mm": float(value),
                    "residual_mm": float(value - source["increment_mm"]),
                }
            )
    return pd.DataFrame(rows)


def add_later_metrics(result: dict, prediction: pd.DataFrame) -> dict:
    """Later-observation metrics on analysis indices 10..14 (common, evaluation only)."""
    later = prediction.loc[prediction["analysis_index"] >= LATER_MIN_INDEX]
    final = later.loc[later["analysis_index"] == later["analysis_index"].max()]
    result = dict(result)
    result.update(
        {
            "later_rmse_mm": float(np.sqrt(np.mean(later["residual_mm"] ** 2))),
            "later_bias_mm": float(later["residual_mm"].mean()),
            "final_mean_error_mm": float(final["residual_mm"].mean()),
            "final_centreline_error_mm": float(
                final.loc[final["sensor"] == "centreline", "residual_mm"].iloc[0]
            ),
        }
    )
    return result


def compute_window_fits(
    data: pd.DataFrame, rate_grid: np.ndarray = RATE_GRID, cutoff_index: int | None = None
) -> tuple[dict, dict]:
    """The nine corrected window fits. Uses ONLY indices <= each window cutoff.

    Returns (fits, profiles): fits keyed (model, window_month); combined fits
    carry the fixed vertical rate from the corresponding natural window.
    `cutoff_index` restricts to a single window (used by the jitter).
    """
    fits: dict[tuple[str, int], dict] = {}
    profiles: dict[tuple[str, int], pd.DataFrame] = {}
    windows = WINDOWS if cutoff_index is None else {24: cutoff_index}
    for month, cutoff in windows.items():
        natural_time, _ = section_matrix(window_frame(data, "natural", cutoff))
        natural_fit, natural_profile = fit_shared_rate(
            window_frame(data, "natural", cutoff),
            rate_grid,
            natural_response(rate_grid, natural_time),
            "natural_vertical",
            month,
        )
        fits[("natural_vertical", month)] = natural_fit
        profiles[("natural_vertical", month)] = natural_profile

        pvd_time, _ = section_matrix(window_frame(data, "pvd", cutoff))
        radial_fit, radial_profile = fit_shared_rate(
            window_frame(data, "pvd", cutoff),
            rate_grid,
            radial_response(rate_grid, pvd_time),
            "pvd_radial",
            month,
        )
        fits[("pvd_radial", month)] = radial_fit
        profiles[("pvd_radial", month)] = radial_profile

        vertical_rate = natural_fit["rate_day_inverse"]
        combined_fit, combined_profile = fit_shared_rate(
            window_frame(data, "pvd", cutoff),
            rate_grid,
            combined_response(rate_grid, pvd_time, vertical_rate),
            "pvd_combined",
            month,
        )
        combined_fit["fixed_vertical_rate_day_inverse"] = float(vertical_rate)
        fits[("pvd_combined", month)] = combined_fit
        profiles[("pvd_combined", month)] = combined_profile
    return fits, profiles


def flatten_fit_row(result: dict) -> dict:
    row = {key: value for key, value in result.items() if key != "amplitudes_mm"}
    for sensor in SENSORS:
        row[f"amplitude_{sensor}_mm"] = result["amplitudes_mm"][sensor]
    return row


# --- Series-convergence verification --------------------------------------------
def convergence_report(data: pd.DataFrame) -> dict:
    """500- vs 1000-term agreement on the actual positive grids; U(0)=0 exact."""
    report: dict[str, float] = {}
    grids = {"rate_grid_4001": RATE_GRID, "jitter_grid_1201": JITTER_GRID}
    times = {
        "natural_calibration": section_matrix(window_frame(data, "natural", WINDOWS[24]))[0],
        "pvd_calibration": section_matrix(window_frame(data, "pvd", WINDOWS[24]))[0],
        "natural_all": section_matrix(data.loc[data["section"] == "natural"])[0],
        "pvd_all": section_matrix(data.loc[data["section"] == "pvd"])[0],
    }
    worst = 0.0
    for gname, grid in grids.items():
        for tname, time in times.items():
            tv = grid[:, None] * time[None, :]
            diff = np.max(
                np.abs(rc.terzaghi_average_degree(tv, 500) - rc.terzaghi_average_degree(tv, 1000))
            )
            report[f"max_abs_diff_500_1000_{gname}_{tname}"] = float(diff)
            worst = max(worst, float(diff))
    report["max_abs_diff_500_1000_all"] = worst
    zero_time = natural_response(RATE_GRID, np.array([0.0]))
    report["max_abs_response_at_t0"] = float(np.max(np.abs(zero_time)))
    large_tv = rc.terzaghi_average_degree(np.array([50.0]), 500)[0]
    report["response_at_tv_50"] = float(large_tv)
    # Legacy 60-term diagnostic magnitude on the same grid (for the report only).
    legacy60 = rc.terzaghi_response(RATE_GRID, times["natural_calibration"])
    corrected = natural_response(RATE_GRID, times["natural_calibration"])
    report["max_abs_diff_legacy60_vs_500_natural_calibration"] = float(
        np.max(np.abs(legacy60 - corrected))
    )
    report["legacy60_u_at_t0"] = float(rc.terzaghi_response(1e-3, 0.0))
    return report


# --- Digitization perturbation (paired with legacy RNG stream) -------------------
def perturbed_repeats(data: pd.DataFrame):
    """Yield 300 perturbed frames; same RNG stream/order as the legacy script."""
    rng = np.random.default_rng(RNG_SEED)
    for repeat in range(JITTER_REPEATS):
        perturbed = data.copy()
        perturbed["settlement_mm"] = perturbed["settlement_mm"] + rng.normal(
            0.0, JITTER_SIGMA_MM, len(perturbed)
        )
        perturbed["increment_mm"] = perturbed.groupby(["section", "sensor"])[
            "settlement_mm"
        ].transform(lambda values: values - values.iloc[0])
        yield repeat, perturbed


def run_jitter(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """300 paired perturbations on the 1201-point grid with the corrected fits.

    Response matrices are computed once and reused; only the combined matrix is
    reassembled per repeat from the cached radial matrix and the repeat's fixed
    vertical response.
    """
    calibration = data.loc[data["analysis_index"] <= WINDOWS[24]]
    natural_time, _ = section_matrix(calibration.loc[calibration["section"] == "natural"])
    pvd_time, _ = section_matrix(calibration.loc[calibration["section"] == "pvd"])
    natural_matrix = natural_response(JITTER_GRID, natural_time)
    radial_matrix = radial_response(JITTER_GRID, pvd_time)
    rows: list[dict] = []
    for repeat, perturbed in perturbed_repeats(data):
        calib = perturbed.loc[perturbed["analysis_index"] <= WINDOWS[24]]
        natural_fit, _ = fit_shared_rate(
            calib.loc[calib["section"] == "natural"],
            JITTER_GRID,
            natural_matrix,
            "natural_vertical",
            24,
        )
        rows.append(_jitter_row(repeat, natural_fit))
        radial_fit, _ = fit_shared_rate(
            calib.loc[calib["section"] == "pvd"], JITTER_GRID, radial_matrix, "pvd_radial", 24
        )
        rows.append(_jitter_row(repeat, radial_fit))
        vertical_rate = natural_fit["rate_day_inverse"]
        vertical = natural_response(np.array([vertical_rate]), pvd_time)[0]
        combined_matrix = 1.0 - (1.0 - vertical[None, :]) * (1.0 - radial_matrix)
        combined_fit, _ = fit_shared_rate(
            calib.loc[calib["section"] == "pvd"], JITTER_GRID, combined_matrix, "pvd_combined", 24
        )
        combined_fit["fixed_vertical_rate_day_inverse"] = float(vertical_rate)
        rows.append(_jitter_row(repeat, combined_fit))
    fits = pd.DataFrame(rows)
    summary_rows = []
    for model in ("natural_vertical", "pvd_radial", "pvd_combined"):
        rates = fits.loc[fits["model"] == model, "rate_day_inverse"].to_numpy(float)
        summary_rows.append(
            {
                "model": model,
                "n_repeats": int(rates.size),
                "rate_p05": float(np.percentile(rates, 5)),
                "rate_p25": float(np.percentile(rates, 25)),
                "rate_p50": float(np.percentile(rates, 50)),
                "rate_p75": float(np.percentile(rates, 75)),
                "rate_p95": float(np.percentile(rates, 95)),
                "n_plateau": int(fits.loc[fits["model"] == model, "plateau_selected"].sum()),
                "n_at_grid_low": int(fits.loc[fits["model"] == model, "selected_at_grid_low"].sum()),
                "n_at_grid_high": int(
                    fits.loc[fits["model"] == model, "selected_at_grid_high"].sum()
                ),
            }
        )
    return fits, pd.DataFrame(summary_rows)


def _jitter_row(repeat: int, fit: dict) -> dict:
    return {
        "repeat": int(repeat),
        "model": fit["model"],
        "rate_day_inverse": fit["rate_day_inverse"],
        "rate_argmin_strict": fit["rate_argmin_strict"],
        "calibration_rmse_mm": fit["calibration_rmse_mm"],
        "plateau_selected": fit["plateau_selected"],
        "n_plateau_candidates": fit["n_plateau_candidates"],
        "selected_at_grid_low": fit["selected_at_grid_low"],
        "selected_at_grid_high": fit["selected_at_grid_high"],
        "fixed_vertical_rate_day_inverse": fit.get("fixed_vertical_rate_day_inverse"),
    }


# --- Natural-rate propagation into the 24 m combined fit -------------------------
def run_propagation(data: pd.DataFrame, natural_fit_24: dict) -> pd.DataFrame:
    pvd_frame = window_frame(data, "pvd", WINDOWS[24])
    pvd_time, _ = section_matrix(pvd_frame)
    full_pvd = data.loc[data["section"] == "pvd"]
    rows: list[dict] = []
    for label, vertical_rate in (
        ("natural_near_low", natural_fit_24["near_rate_low"]),
        ("natural_optimum", natural_fit_24["rate_day_inverse"]),
        ("natural_near_high", natural_fit_24["near_rate_high"]),
    ):
        fit, _ = fit_shared_rate(
            pvd_frame,
            RATE_GRID,
            combined_response(RATE_GRID, pvd_time, float(vertical_rate)),
            "pvd_combined",
            24,
        )
        fit["fixed_vertical_rate_day_inverse"] = float(vertical_rate)
        prediction = predict_result(fit, full_pvd)
        fit = add_later_metrics(fit, prediction)
        rows.append(
            {
                "vertical_rate_source": label,
                "vertical_rate_day_inverse": float(vertical_rate),
                "radial_rate_day_inverse": fit["rate_day_inverse"],
                "radial_near_low": fit["near_rate_low"],
                "radial_near_high": fit["near_rate_high"],
                "calibration_rmse_mm": fit["calibration_rmse_mm"],
                "later_rmse_mm": fit["later_rmse_mm"],
                "later_bias_mm": fit["later_bias_mm"],
                "final_mean_error_mm": fit["final_mean_error_mm"],
                "rate_identification": fit["rate_identification"],
            }
        )
    return pd.DataFrame(rows)


# --- Conditional geometry mapping --------------------------------------------------
def run_mapping(fits: dict) -> pd.DataFrame:
    rows: list[dict] = []
    natural = fits[("natural_vertical", 24)]
    for drainage_length in DRAINAGE_LENGTHS_M:
        rows.append(
            {
                "model": "natural_vertical",
                "mapping_assumption": f"drainage_length_{drainage_length:.1f}_m",
                "rate_day_inverse": natural["rate_day_inverse"],
                "derived_coefficient_m2_year": natural["rate_day_inverse"]
                * drainage_length**2
                * DAYS_PER_YEAR,
                "rate_identification": natural["rate_identification"],
            }
        )
    for model in ("pvd_radial", "pvd_combined"):
        fit = fits[(model, 24)]
        rows.append(
            {
                "model": model,
                "mapping_assumption": "ideal_Barron_no_smear",
                "rate_day_inverse": fit["rate_day_inverse"],
                "derived_coefficient_m2_year": fit["rate_day_inverse"]
                * PVD_DE_M**2
                * PVD_F
                / 8.0
                * DAYS_PER_YEAR,
                "rate_identification": fit["rate_identification"],
            }
        )
    return pd.DataFrame(rows)


# --- Two-term (primary + log) exploratory sensitivity ------------------------------
def fit_two_term_model(
    frame: pd.DataFrame,
    rate_grid: np.ndarray,
    response_matrix: np.ndarray,
    model: str,
    full_frame: pd.DataFrame,
    vertical_rate_day: float | None = None,
) -> dict:
    """Primary + A_L*log1p(t/365.25) per-sensor NNLS; exploratory sensitivity only."""
    time, observed = section_matrix(frame)
    long_term = np.log1p(time / DAYS_PER_YEAR)
    total_sse = None
    coefficients = []
    for sensor_index in range(observed.shape[0]):
        coef, sse = rc.profile_nnls_2col(response_matrix.T, long_term, observed[sensor_index])
        total_sse = sse if total_sse is None else total_sse + sse
        coefficients.append(coef)
    observed_energy_total = float(np.sum(observed**2))
    sel = _plateau_selection(total_sse, PLATEAU_RTOL * observed_energy_total)
    i_sel = sel["selected_index"]
    best_rate = float(rate_grid[i_sel])
    calibration_rmse = float(np.sqrt(max(total_sse[i_sel], 0.0) / observed.size))
    rows: list[dict] = []
    for sensor_index, sensor in enumerate(SENSORS):
        sensor_frame = full_frame.loc[full_frame["sensor"] == sensor].sort_values("analysis_index")
        eval_time = sensor_frame["elapsed_day_from_anchor"].to_numpy(float)
        primary = predict_response(model.replace("_long_term", ""), best_rate, eval_time, vertical_rate_day)
        design = np.column_stack([primary, np.log1p(eval_time / DAYS_PER_YEAR)])
        predicted = design @ coefficients[sensor_index][:, i_sel]
        for (_, source), value in zip(sensor_frame.iterrows(), predicted):
            rows.append(
                {
                    "sensor": sensor,
                    "analysis_index": int(source["analysis_index"]),
                    "observed_increment_mm": float(source["increment_mm"]),
                    "residual_mm": float(value - source["increment_mm"]),
                }
            )
    prediction = pd.DataFrame(rows)
    later = prediction.loc[prediction["analysis_index"] >= LATER_MIN_INDEX]
    result = {
        "model": model,
        "rate_day_inverse": best_rate,
        "rate_argmin_strict": float(rate_grid[sel["strict_index"]]),
        "plateau_selected": bool(sel["n_plateau_candidates"] > 1),
        "n_plateau_candidates": sel["n_plateau_candidates"],
        "selected_at_grid_low": bool(i_sel == 0),
        "selected_at_grid_high": bool(i_sel == rate_grid.size - 1),
        "rate_identification": _identification_flag(i_sel, rate_grid.size, sel["n_plateau_candidates"]),
        "calibration_rmse_mm": calibration_rmse,
        "later_rmse_mm": float(np.sqrt(np.mean(later["residual_mm"] ** 2))),
        "later_bias_mm": float(later["residual_mm"].mean()),
        "primary_amplitude_mean_mm": float(np.mean([c[0, i_sel] for c in coefficients])),
        "long_term_amplitude_mean_mm": float(np.mean([c[1, i_sel] for c in coefficients])),
    }
    for sensor_index, sensor in enumerate(SENSORS):
        result[f"primary_amplitude_{sensor}_mm"] = float(coefficients[sensor_index][0, i_sel])
        result[f"log_amplitude_{sensor}_mm"] = float(coefficients[sensor_index][1, i_sel])
    if vertical_rate_day is not None:
        result["fixed_vertical_rate_day_inverse"] = float(vertical_rate_day)
    return result


def run_longterm(data: pd.DataFrame, natural_fit_24: dict) -> pd.DataFrame:
    pvd_calibration = window_frame(data, "pvd", WINDOWS[24])
    pvd_time, _ = section_matrix(pvd_calibration)
    full_pvd = data.loc[data["section"] == "pvd"]
    vertical_rate = natural_fit_24["rate_day_inverse"]
    return pd.DataFrame(
        [
            fit_two_term_model(
                pvd_calibration,
                RATE_GRID,
                radial_response(RATE_GRID, pvd_time),
                "pvd_radial_long_term",
                full_pvd,
            ),
            fit_two_term_model(
                pvd_calibration,
                RATE_GRID,
                combined_response(RATE_GRID, pvd_time, vertical_rate),
                "pvd_combined_long_term",
                full_pvd,
                vertical_rate,
            ),
        ]
    )


# --- Main figure ---------------------------------------------------------------------
def _fine_curve(model: str, rate: float, amplitude: float, t_fine: np.ndarray, vertical=None):
    return amplitude * predict_response(model, rate, t_fine, vertical)


def make_figure(data: pd.DataFrame, fits: dict) -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11.0,
            "axes.titlesize": 11.0,
            "axes.labelsize": 11.0,
            "xtick.labelsize": 11.0,
            "ytick.labelsize": 11.0,
            "legend.fontsize": 11.0,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    sensor_colors = {"left_4m": COLORS["blue"], "centreline": COLORS["orange"], "right_4m": COLORS["green"]}
    sensor_markers = {"left_4m": "o", "centreline": "s", "right_4m": "^"}
    sensor_labels = {"left_4m": "left 4 m", "centreline": "centreline", "right_4m": "right 4 m"}

    fig, axes = plt.subplots(2, 1, figsize=(6.3, 6.5), sharex=False)
    fig.subplots_adjust(left=0.13, right=0.97, top=0.96, bottom=0.185, hspace=0.42)

    for ax, section, panel in zip(axes, ("natural", "pvd"), ("a", "b")):
        section_data = data.loc[data["section"] == section]
        cutoff_day = section_data.loc[
            section_data["analysis_index"] == WINDOWS[24], "elapsed_day_from_anchor"
        ].mean()
        for sensor in SENSORS:
            source = section_data.loc[section_data["sensor"] == sensor].sort_values("analysis_index")
            calib = source["analysis_index"] <= WINDOWS[24]
            ax.scatter(
                source.loc[calib, "elapsed_day_from_anchor"] / DAYS_PER_YEAR,
                source.loc[calib, "increment_mm"],
                s=22,
                marker=sensor_markers[sensor],
                color=sensor_colors[sensor],
                edgecolor="white",
                linewidth=0.4,
                zorder=4,
            )
            ax.scatter(
                source.loc[~calib, "elapsed_day_from_anchor"] / DAYS_PER_YEAR,
                source.loc[~calib, "increment_mm"],
                s=26,
                marker=sensor_markers[sensor],
                facecolor="white",
                edgecolor=sensor_colors[sensor],
                linewidth=1.0,
                zorder=4,
            )
        t_fine = np.linspace(0.0, section_data["elapsed_day_from_anchor"].max(), 400)
        if section == "natural":
            fit = fits[("natural_vertical", 24)]
            for sensor in SENSORS:
                ax.plot(
                    t_fine / DAYS_PER_YEAR,
                    _fine_curve("natural_vertical", fit["rate_day_inverse"],
                                fit["amplitudes_mm"][sensor], t_fine),
                    color=sensor_colors[sensor],
                    linestyle="-",
                    linewidth=1.5,
                    zorder=3,
                )
        else:
            radial = fits[("pvd_radial", 24)]
            combined = fits[("pvd_combined", 24)]
            for sensor in SENSORS:
                ax.plot(
                    t_fine / DAYS_PER_YEAR,
                    _fine_curve("pvd_radial", radial["rate_day_inverse"],
                                radial["amplitudes_mm"][sensor], t_fine),
                    color=sensor_colors[sensor],
                    linestyle="-",
                    linewidth=1.5,
                    zorder=3,
                )
                ax.plot(
                    t_fine / DAYS_PER_YEAR,
                    _fine_curve("pvd_combined", combined["rate_day_inverse"],
                                combined["amplitudes_mm"][sensor], t_fine,
                                combined["fixed_vertical_rate_day_inverse"]),
                    color=sensor_colors[sensor],
                    linestyle=(0, (4, 2)),
                    linewidth=1.5,
                    zorder=3,
                )
        ax.axvline(cutoff_day / DAYS_PER_YEAR, color=COLORS["ink"], linestyle=(0, (3, 2)), linewidth=1.0)
        ax.set_title(f"({panel}) {'Natural-ground' if section == 'natural' else 'PVD'} section")
        ax.set_xlabel("Time from analysis anchor (year)")
        ax.set_ylabel("Settlement increment (mm)")
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", color="#DDE2E4", linewidth=0.55, zorder=0)
        ax.tick_params(direction="out", length=3)

    handles = [
        Line2D([0], [0], marker=sensor_markers[s], linestyle="none", color=sensor_colors[s],
               markersize=6.0, label=sensor_labels[s])
        for s in SENSORS
    ] + [
        Line2D([0], [0], marker="o", linestyle="none", color=COLORS["gray"], markersize=6.0,
               label="calibration"),
        Line2D([0], [0], marker="o", linestyle="none", markerfacecolor="white",
               markeredgecolor=COLORS["gray"], markersize=6.0, label="later"),
        Line2D([0], [0], color=COLORS["gray"], linestyle="-", linewidth=1.5,
               label="vertical/radial fit"),
        Line2D([0], [0], color=COLORS["gray"], linestyle=(0, (4, 2)), linewidth=1.5,
               label="combined fit"),
    ]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 0.0), ncol=4,
               handlelength=1.9, columnspacing=1.1, handletextpad=0.5, borderaxespad=0.0)
    FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURES / "haarajoki_corrected_main.pdf")
    fig.savefig(FIGURES / "haarajoki_corrected_main.png", dpi=400)
    plt.close(fig)


# --- Orchestration ------------------------------------------------------------------
def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    data = load_data()

    convergence = convergence_report(data)
    fits, profiles = compute_window_fits(data)

    fit_rows: list[dict] = []
    prediction_frames: list[pd.DataFrame] = []
    amplitude_rows: list[dict] = []
    for (model, month), fit in fits.items():
        section = "natural" if model == "natural_vertical" else "pvd"
        prediction = predict_result(fit, data.loc[data["section"] == section])
        fit = add_later_metrics(fit, prediction)
        fits[(model, month)] = fit
        fit_rows.append(flatten_fit_row(fit))
        prediction_frames.append(prediction)
        for sensor in SENSORS:
            amplitude_rows.append(
                {
                    "model": model,
                    "window_month": month,
                    "sensor": sensor,
                    "amplitude_mm": fit["amplitudes_mm"][sensor],
                    "rate_day_inverse": fit["rate_day_inverse"],
                }
            )
    fits_frame = pd.DataFrame(fit_rows)
    predictions = pd.concat(prediction_frames, ignore_index=True)
    profiles_frame = pd.concat(profiles.values(), ignore_index=True)
    amplitudes_frame = pd.DataFrame(amplitude_rows)

    jitter_fits, jitter_summary = run_jitter(data)
    propagation = run_propagation(data, fits[("natural_vertical", 24)])
    mapping = run_mapping(fits)
    longterm = run_longterm(data, fits[("natural_vertical", 24)])

    fits_frame.to_csv(RESULTS / "haarajoki_corrected_window_fits.csv", index=False)
    profiles_frame.to_csv(RESULTS / "haarajoki_corrected_profiles.csv", index=False)
    predictions.to_csv(RESULTS / "haarajoki_corrected_predictions.csv", index=False)
    amplitudes_frame.to_csv(RESULTS / "haarajoki_corrected_amplitudes.csv", index=False)
    jitter_fits.to_csv(RESULTS / "haarajoki_corrected_jitter_fits.csv", index=False)
    jitter_summary.to_csv(RESULTS / "haarajoki_corrected_jitter_summary.csv", index=False)
    propagation.to_csv(RESULTS / "haarajoki_corrected_propagation.csv", index=False)
    mapping.to_csv(RESULTS / "haarajoki_corrected_mapping.csv", index=False)
    longterm.to_csv(RESULTS / "haarajoki_corrected_longterm.csv", index=False)
    (RESULTS / "haarajoki_corrected_convergence.json").write_text(
        json.dumps(convergence, indent=2), encoding="utf-8"
    )

    make_figure(data, fits)

    summary = {
        "scope": (
            "Corrected retrospective three-line point estimates; converged 500-term series, "
            "exact U(0)=0, explicit plateau/bound flags. Descriptive intervals only."
        ),
        "window_fits": fit_rows,
        "jitter_summary": jitter_summary.to_dict(orient="records"),
        "propagation": propagation.to_dict(orient="records"),
        "mapping": mapping.to_dict(orient="records"),
        "longterm": longterm.to_dict(orient="records"),
        "convergence": convergence,
    }
    (RESULTS / "haarajoki_corrected_summary.json").write_text(
        json.dumps(summary, indent=2, default=float), encoding="utf-8"
    )
    print(json.dumps({"window_fits": fit_rows, "convergence": convergence}, indent=2, default=float))


if __name__ == "__main__":
    main()
