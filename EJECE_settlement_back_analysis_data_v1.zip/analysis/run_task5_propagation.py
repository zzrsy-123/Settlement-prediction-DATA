"""Task 5: integrated conditional propagation for Ballina (SCENARIO propagation).

Per fixed covariance scenario (sigma 5/10/20 mm x ell 0/30/90 d) and per
long-term model form (log1p, sqrt, linear), 250 parametric simulations:
  1. draw absolute-observation errors e ~ N(0, C_abs) over the 7 observation
     times (anchor 58 d + 6 training times); increment noise = e_i - e_0,
     which automatically carries the shared-anchor term;
  2. add the noise to the OBSERVED training increments and refit with the
     same whitened NNLS profile estimator as Task 2;
  3. draw a unit-cell diameter factor u ~ U(-0.1, +0.1); the converted
     coefficient uses de(u) = de0*(1+u) in BOTH D_cell^2 and the Barron
     F(N) = ln(N) - 0.75 geometry factor (N = de/dw);
  4. record refit rate, amplitudes, converted c_r, and forecasts at calendar
     days 496/974 (elapsed dt = t - 58 in every response term);
  5. the forecast absolute level is (s0 + e_0) + model increment, so the
     anchor perturbation propagates back to the absolute forecast.

Reported SEPARATELY per model form -- no averaged posterior over models. This
is a Gaussian perturbation of the OBSERVED record around the observed values:
the resulting 5-95 spreads form a conditional input-perturbation sensitivity
distribution, NOT a sampling distribution, parametric bootstrap around the
fitted model mean, or predictive coverage. A loading-factor uncertainty is
NOT included: the settlement amplitudes are freely profiled, so a load-scale
factor is not separately identifiable from the fitted amplitude and is not
covered here. This is not comprehensive uncertainty (no layering/smear/creep/
model-form mixing).
"""
from __future__ import annotations

import json
import math

import numpy as np
import pandas as pd

import revision_core as rc

N_SIMS = 250
SEED = 20260929
FORMS = ("log1p", "sqrt", "linear")
SIGMAS_MM = (5.0, 10.0, 20.0)
ELLS_D = (0.0, 30.0, 90.0)
FORECAST_DAYS = (496.0, 974.0)
D_CELL_M = rc.D_CELL_M
D_DRAIN_M = rc.D_DRAIN_M


def cr_with_de(k_day, de_factor):
    de = D_CELL_M * de_factor
    n_ratio = de / D_DRAIN_M
    f_barron = math.log(n_ratio) - 0.75
    return k_day * de**2 * f_barron / 8.0 * 365.0


class ScenarioCache:
    """Precomputed per-(form, scenario) grids/whiteners for propagation."""

    def __init__(self, form, sigma_mm, ell, times, dt_train):
        self.form = form
        x1, x2 = rc.design_columns(dt_train, rc.K_GRID, form)
        sigma_m = sigma_mm / 1000.0
        self.c_abs = rc.absolute_cov(times, sigma_m, ell)
        self.fac_abs = rc.whiten(self.c_abs)
        cov_inc = rc.increment_cov(times, sigma_m, ell)
        fac_inc = rc.whiten(cov_inc)
        self.fac_inc = fac_inc
        self.x1w = np.linalg.solve(fac_inc, x1)
        self.x2w = np.linalg.solve(fac_inc, x2)
        dt_fore = np.asarray(FORECAST_DAYS) - rc.T0_DAY  # elapsed, not calendar
        self.g_fore = rc.long_term_component(dt_fore, form)
        self.p_fore = 1.0 - np.exp(-dt_fore[:, None] * np.asarray(rc.K_GRID)[None, :])

    def propagate(self, y_sim, anchor_shift, de_factor, s0):
        """Refit one perturbed record and forecast absolute settlement."""
        yw = np.linalg.solve(self.fac_inc, y_sim)
        coefs, chi2 = rc.profile_nnls_2col(self.x1w, self.x2w, yw)
        i = int(np.argmin(chi2))
        k_hat = float(rc.K_GRID[i])
        a_hat, b_hat = float(coefs[0, i]), float(coefs[1, i])
        fore = (s0 + anchor_shift) + a_hat * self.p_fore[:, i] + b_hat * self.g_fore
        return {
            "k_day_inverse": k_hat,
            "amplitude_primary_m": a_hat, "amplitude_longterm_m": b_hat,
            "cr_eq_m2_year": cr_with_de(k_hat, de_factor),
            "forecast_day496_m": float(fore[0]),
            "forecast_day974_m": float(fore[1]),
            "k_at_grid_low": i == 0, "k_at_grid_high": i == rc.K_GRID.size - 1,
            "primary_amplitude_zero": a_hat <= 1e-12,
            "longterm_amplitude_zero": b_hat <= 1e-12,
        }


def main():
    rc.RESULTS.mkdir(parents=True, exist_ok=True)
    day, settlement, s0, _ = rc.load_ballina()
    train, _ = rc.ballina_train_later(day)
    times = np.concatenate([[rc.T0_DAY], day[train]])
    y_obs = settlement[train] - s0
    dt_train = times[1:] - rc.T0_DAY
    rng = np.random.default_rng(SEED)
    rows = []
    for form in FORMS:
        for sigma_mm in SIGMAS_MM:
            for ell in ELLS_D:
                cache = ScenarioCache(form, sigma_mm, ell, times, dt_train)
                for sim in range(N_SIMS):
                    e_abs = cache.fac_abs @ rng.standard_normal(times.size)
                    de_factor = float(rng.uniform(0.9, 1.1))
                    out = cache.propagate(y_obs + (e_abs[1:] - e_abs[0]), e_abs[0], de_factor, s0)
                    rows.append({"model": form, "sigma_mm": sigma_mm, "ell_day": ell,
                                 "sim": sim, "de_factor": de_factor, **out})
    df = pd.DataFrame(rows)
    df.to_csv(rc.RESULTS / "input_propagation_samples.csv", index=False)

    def q(s, p):
        return float(s.quantile(p))

    summ = df.groupby(["model", "sigma_mm", "ell_day"]).agg(
        n_sims=("sim", "count"),
        k_median=("k_day_inverse", "median"),
        cr_q05=("cr_eq_m2_year", lambda s: q(s, 0.05)),
        cr_median=("cr_eq_m2_year", "median"),
        cr_q95=("cr_eq_m2_year", lambda s: q(s, 0.95)),
        s974_q05=("forecast_day974_m", lambda s: q(s, 0.05)),
        s974_median=("forecast_day974_m", "median"),
        s974_q95=("forecast_day974_m", lambda s: q(s, 0.95)),
        s496_q05=("forecast_day496_m", lambda s: q(s, 0.05)),
        s496_q95=("forecast_day496_m", lambda s: q(s, 0.95)),
        n_k_grid_low=("k_at_grid_low", "sum"),
        n_k_grid_high=("k_at_grid_high", "sum"),
        n_primary_zero=("primary_amplitude_zero", "sum"),
        n_longterm_zero=("longterm_amplitude_zero", "sum"),
    ).reset_index()
    summ.to_csv(rc.RESULTS / "input_propagation_summary.csv", index=False)
    meta = {
        "seed": SEED, "n_sims_per_scenario_form": N_SIMS,
        "de_uncertainty": "uniform +/-10% on unit-cell diameter; enters D_cell^2 and Barron F(N)",
        "noise_model": "absolute errors N(0, C_abs); increments carry e_i - e_0 (shared anchor)",
        "forecast_level": "absolute forecast = (s0 + e_0) + model increment at elapsed dt = t - 58",
        "load_scale": ("NOT covered: amplitudes are freely profiled, so a loading-factor "
                       "uncertainty cannot be separated from the fitted amplitude"),
        "status": ("Gaussian perturbation of the observed record; reported separately per "
                   "model form; 5-95 spreads are a conditional input-perturbation "
                   "sensitivity distribution, NOT a sampling distribution or validated "
                   "confidence/prediction coverage; no layering/smear/creep/model-form "
                   "mixing included"),
    }
    (rc.RESULTS / "input_propagation_meta.json").write_text(json.dumps(meta, indent=2))
    print(summ[summ["sigma_mm"] == 10.0].to_string(index=False))


if __name__ == "__main__":
    main()
