"""V2 figure: new observational baselines (Ballina) and FE forward benchmark.

One 6.3 in wide, 11 pt figure, two STACKED panels with outside legends:
(a) Ballina cutoff 215 d: v1 log-form fit (preserved reference) with the new
    Asaoka 30 d recurrence and whole-window linearized-hyperbola forecasts on
    the common 11 later observations 243-974 d.
(b) FE layered two-step case (30 kPa @ 0 d + 20 kPa @ 90 d), cutoff 730 d,
    noiseless: FE observations with homogeneous single-step and
    loading-history-aware inversion responses.

Visible labels carry NO internal version tags (no 'v1'/'v2' strings).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import revision_core as rc
import v2_observational_baselines as va
import v2_fe_benchmark as vb

plt.rcParams.update({
    "font.size": 11, "axes.labelsize": 11, "axes.titlesize": 11,
    "xtick.labelsize": 11, "ytick.labelsize": 11, "legend.fontsize": 11,
    "figure.dpi": 200, "savefig.dpi": 600, "lines.linewidth": 1.4,
})
COLORS = {"obs_cal": "#1a1a1a", "obs_late": "#b2182b", "v1log": "#7f7f7f",
          "asaoka": "#2166ac", "hyper": "#43931f", "single": "#d6604d",
          "history": "#2166ac", "fe": "#1a1a1a", "fe_late": "#b2182b"}


def main():
    rc.FIGURES.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 6.4))

    # --- panel (a): Ballina ----------------------------------------------------
    ax = axes[0]
    day, settlement, s0, _ = rc.load_ballina()
    v1 = pd.read_csv(rc.RESULTS / "ballina_per_point_predictions.csv")
    v1log = v1[v1["model"] == "log1p"]
    t_fine = np.linspace(58, 974, 500)
    fit_a = va.fit_asaoka(day, settlement, 215, 30)
    fit_h = va.fit_linearized_hyperbola(day, settlement, s0, 215)
    ax.plot(v1log["day"], v1log["prediction_m"], color=COLORS["v1log"], ls="--",
            label="log-form fit (reference)", zorder=2)
    ax.plot(t_fine, va.predict_asaoka(fit_a, t_fine), color=COLORS["asaoka"],
            label="Asaoka 30 d recurrence", zorder=3)
    ax.plot(t_fine, va.predict_linearized_hyperbola(fit_h, t_fine, s0),
            color=COLORS["hyper"], ls="-.", label="linearized hyperbola", zorder=3)
    cal = (day >= 58) & (day <= 215)
    late = day > 215
    ax.plot(day[cal], settlement[cal], "o", ms=4, color=COLORS["obs_cal"],
            label="calibration readings", zorder=4)
    ax.plot(day[late], settlement[late], "o", ms=4, mfc="none",
            mec=COLORS["obs_late"], mew=1.2, label="later readings (243-974 d)", zorder=4)
    ax.axvline(215, color="#bbbbbb", lw=0.8, zorder=1)
    ax.set_xlabel("time (d)")
    ax.set_ylabel("settlement (m)")
    ax.set_title("(a) Ballina, cutoff 215 d", loc="left")
    ax.set_xlim(50, 990)
    ax.set_ylim(0.40, 1.65)
    ax.set_xticks([200, 400, 600, 800])
    ax.set_yticks([0.50, 0.75, 1.00, 1.25, 1.50])

    # --- panel (b): FE layered two-step case ------------------------------------
    ax = axes[1]
    case = "layered_30_at0_20_at90"
    loads = vb.CASES[case]["loads"]
    obs = pd.read_csv(rc.RESULTS / "fe_observations.csv")
    obs = obs[obs["case"] == case]
    inv = pd.read_csv(rc.RESULTS / "fe_inversion_realizations.csv")
    inv = inv[(inv["case"] == case) & inv["noise_free"] & (inv["cutoff_day"] == 730)]
    t_fine = np.linspace(0, 1825, 600)
    for form, key, lab, ls in (("single_step", "single", "single-step inversion", "--"),
                               ("history_aware", "history", "history-aware inversion", "-")):
        row = inv[inv["inversion"] == form].iloc[0]
        x = vb.design_columns_inversion(form, t_fine, loads, [row["alpha_hat_tv_per_day"]])
        ax.plot(t_fine, row["amplitude_hat_m"] * x[0], color=COLORS[key], ls=ls,
                label=lab, zorder=3)
    cal = obs["day"] <= 730
    ax.plot(obs["day"][cal], obs["settlement_clean_m"][cal], "s", ms=3.5,
            color=COLORS["fe"], label="FE readings (calibration)", zorder=4)
    ax.plot(obs["day"][~cal], obs["settlement_clean_m"][~cal], "s", ms=3.5,
            mfc="none", mec=COLORS["fe_late"], mew=1.2,
            label="FE readings (later 900-1825 d)", zorder=4)
    ax.axvline(730, color="#bbbbbb", lw=0.8, zorder=1)
    ax.set_xlabel("time (d)")
    ax.set_ylabel("settlement (m)")
    ax.set_title("(b) FE layered case, cutoff 730 d", loc="left")
    ax.set_xlim(-30, 1850)
    ax.set_ylim(0.0, 0.16)
    ax.set_xticks([0, 250, 500, 750, 1000, 1250, 1500, 1750])
    ax.set_yticks([0.00, 0.05, 0.10, 0.15])

    axes[0].legend(loc="upper center", bbox_to_anchor=(0.5, -0.30), ncols=2,
                   frameon=False, fontsize=11, handlelength=1.8)
    axes[1].legend(loc="upper center", bbox_to_anchor=(0.5, -0.30), ncols=2,
                   frameon=False, fontsize=11, handlelength=1.8)
    fig.subplots_adjust(left=0.11, right=0.97, top=0.955, bottom=0.19, hspace=1.05)
    for ext in ("png", "pdf"):
        fig.savefig(rc.FIGURES / f"v2_baselines_and_fe_benchmark.{ext}")
    print("saved", rc.FIGURES / "v2_baselines_and_fe_benchmark.png")


if __name__ == "__main__":
    main()
