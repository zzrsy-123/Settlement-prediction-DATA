"""V2 Part B: independent numerical forward benchmark for the inversion.

A small standard 1D linear finite-element SEMIDISCRETE consolidation generator
(NumPy/SciPy linear algebra only, no custom framework):

    m_v du/dt = d/dz[(k/gamma_w) du/dz] + m_v dq/dt

with top drained (u = 0 at z = 0), base no-flow (du/dz = 0 at z = H),
piecewise-constant m_v and conductivity with the layer interface ON the mesh,
and pressure/flux continuity by standard assembly. Consistent element matrices
    mass        m_v h/6  [[2, 1], [1, 2]]
    conductivity (k/gamma_w)/h [[1, -1], [-1, 1]]
The semidiscrete system M du/dt = -K u + sources is propagated EXACTLY by the
generalized symmetric eigenproblem K v = lambda M v (scipy.linalg.eigh), so no
time-discretization error is introduced. Instant uniform load jumps raise the
undrained free-node pressure to the jump value; the surface Dirichlet node
stays at zero, producing an O(h) early surface-element effect that is
documented and convergence-tested. Settlement s = integral m_v (q - u) dz in
metres. Prescribed step loads are combined by linear superposition.

The generator NEVER calls the analytical Terzaghi solution to produce
observations; the analytical reference is used ONLY for the homogeneous-limit
convergence test. All soil properties are specified SYNTHETIC values, not site
measurements. Layered fitted coefficients are EFFECTIVE values; no 'true
recovered cv' is claimed for the layered cases.

Exploratory protocol (settings exported before each reproducible run):
  H = 6 m, two 3 m layers; homogeneous m_v = 3e-4 1/kPa, cv = 4 m^2/year;
  layered top (m_v = 3e-4, cv = 4), bottom (m_v = 6e-4, cv = 0.5);
  k/gamma_w = m_v cv/365 in m^2/(kPa day) (gamma_w = 9.81 kPa/m if k needed).
  Cases: homogeneous 50 kPa @ 0 d; layered 50 @ 0; layered 30 @ 0 + 20 @ 90 d.
  Small-strain totals 0.09-0.135 m.
  Observation days: 7,14,30,60,90,120,180,240,365,500,730,900,1200,1500,1825.
  Calibration cutoffs 240/730 d; common later days 900/1200/1500/1825.
  Inversions: (i) homogeneous analytical single-step; (ii) loading-history-aware
  homogeneous analytical superposition with KNOWN prescribed load weights;
  both with profiled nonnegative total amplitude (NNLS) over one common rate
  grid. Noise: iid N(0, 2 mm), 29 noisy + 1 noiseless per case, seed 20260930,
  common random numbers across cases per realization index.

Post-review additions (exploratory, not preregistered):
  * Mesh acceptance gate: production mesh 160 is accepted only if (a) the
    homogeneous max settlement error is < 5e-4 m, (b) the layered case-3
    max |s_160 - s_320| self-difference is < 2e-4 m, and (c) the last two
    observed refinement ratios are reasonably near 4. Any violation fails
    the run. The t=0 nodal surface Dirichlet effect stays documented.
  * Parameter mesh sensitivity: the NOISELESS homogeneous and layered
    two-step inversions are repeated at meshes 80/160/320 on both windows
    with the same free-amplitude grid. Response convergence does NOT
    guarantee parameter convergence on a flat valley; this is a diagnostic,
    not a search for a flattering mesh.
  * Known-amplitude control (homogeneous case only): the total amplitude is
    FIXED at the prescribed m_v q H = 0.09 m -- deliberately supplied exact
    synthetic information -- and the rate is estimated from a scalar SSE grid
    on the SAME observations (same seed 20260930 noise bank, same 29 noisy +
    1 clean, same rate grid, same 240/730 windows). This exposes
    amplitude-rate confounding; it is NOT a claim of field feasibility or of
    an independently measurable amplitude.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from scipy.linalg import eigh

import revision_core as rc

# --- Fixed protocol ------------------------------------------------------------
H_TOTAL = 6.0          # m
H_LAYER = 3.0          # m
GAMMA_W = 9.81         # kPa/m (only needed if k itself is required)
T_OBS = np.array([7, 14, 30, 60, 90, 120, 180, 240, 365, 500, 730,
                  900, 1200, 1500, 1825], dtype=float)
CUTOFFS = (240.0, 730.0)
LATER_DAYS = np.array([900.0, 1200.0, 1500.0, 1825.0])
SIGMA_NOISE_M = 0.002
N_REAL = 30            # 1 noiseless (index 0) + 29 noisy
SEED = 20260930
CONVERGENCE_MESHES = (40, 80, 160, 320)
MAX_SETTLEMENT_ERROR_TOL_M = 5.0e-4  # mesh selection rule: comfortably below 2 mm
LAYERED_SELF_DIFF_TOL_M = 2.0e-4     # layered case-3 |s_160 - s_320| gate
REFINEMENT_RATIO_RANGE = (3.0, 5.0)  # "reasonably near 4" for O(h^2)
TRUTH_RATE_TV_PER_DAY = (4.0 / 365.0) / H_TOTAL**2  # homogeneous reference rate
KNOWN_AMPLITUDE_M = 3.0e-4 * 50.0 * H_TOTAL  # prescribed m_v q H = 0.09 m
ALPHA_GRID = np.sort(np.concatenate([
    np.geomspace(1.0e-6, 3.0e-2, 2001), [TRUTH_RATE_TV_PER_DAY]]))

CASES = {
    "homogeneous_50": {
        "mv": (3.0e-4, 3.0e-4), "cv_m2_yr": (4.0, 4.0),
        "loads": ((0.0, 50.0),),
        "note": "homogeneous reference; analytical limit exists (test only)"},
    "layered_50": {
        "mv": (3.0e-4, 6.0e-4), "cv_m2_yr": (4.0, 0.5),
        "loads": ((0.0, 50.0),),
        "note": "layered; fitted coefficient is EFFECTIVE, not a recovered true cv"},
    "layered_30_at0_20_at90": {
        "mv": (3.0e-4, 6.0e-4), "cv_m2_yr": (4.0, 0.5),
        "loads": ((0.0, 30.0), (90.0, 20.0)),
        "note": "two-step prescribed loading; history-aware inversion uses known weights 0.6/0.4"},
}
INVERSION_FORMS = ("single_step", "history_aware")
PRODUCTION_MESH = 160  # chosen by the convergence rule below; recorded in outputs
MESH_SENSITIVITY_MESHES = (80, 160, 320)
MESH_SENSITIVITY_CASES = ("homogeneous_50", "layered_30_at0_20_at90")


# --- FE semidiscrete generator --------------------------------------------------
class FEConsolidation1D:
    """Standard 1D linear-FE semidiscrete consolidation on a uniform mesh."""

    def __init__(self, mv_layers, cv_yr_layers, n_elem, h_total=H_TOTAL, h_layer=H_LAYER):
        if n_elem % 2:
            raise ValueError("n_elem must be even so the layer interface lies on the mesh")
        self.n_elem = int(n_elem)
        self.h = h_total / n_elem
        self.z = np.linspace(0.0, h_total, n_elem + 1)
        z_mid = 0.5 * (self.z[:-1] + self.z[1:])
        layer = (z_mid >= h_layer).astype(int)  # 0 top, 1 bottom
        mv = np.asarray(mv_layers, float)[layer]
        cond = mv * np.asarray(cv_yr_layers, float)[layer] / 365.0  # k/gamma_w, m^2/(kPa day)
        n_node = n_elem + 1
        M = np.zeros((n_node, n_node))
        K = np.zeros((n_node, n_node))
        me = self.h / 6.0 * np.array([[2.0, 1.0], [1.0, 2.0]])
        ke = (1.0 / self.h) * np.array([[1.0, -1.0], [-1.0, 1.0]])
        for e in range(n_elem):
            idx = (e, e + 1)
            M[np.ix_(idx, idx)] += mv[e] * me
            K[np.ix_(idx, idx)] += cond[e] * ke
        self.M_full, self.K_full = M, K
        self.M, self.K = M[1:, 1:], K[1:, 1:]  # free nodes 1..n (top drained u=0)
        # settlement quadrature: int m_v u dz = g^T u_full ; int m_v dz = mv_int_total
        g = np.zeros(n_node)
        for e in range(n_elem):
            g[e] += mv[e] * self.h / 2.0
            g[e + 1] += mv[e] * self.h / 2.0
        self.g = g
        self.mv_int_total = float(np.sum(mv * self.h))
        self.layers = layer
        self.mv_elem, self.cond_elem = mv, cond
        # exact modal basis of the SEMIDISCRETE system
        self.lam, self.V = eigh(self.K, self.M)

    def _free_decay(self, u0_free, t):
        """u(t) for M du/dt = -K u, u(0) = u0_free, by exact modal propagation."""
        c = self.V.T @ (self.M @ u0_free)
        return self.V @ (c[:, None] * np.exp(-self.lam[:, None] * np.asarray(t, float)[None, :]))

    def pressure(self, loads, t_out):
        """Pore pressure (kPa) at ALL nodes for prescribed step loads (t_j, dq_j).

        Linear superposition; each jump raises undrained free-node pressure by dq.
        Right-continuous at load times: u(t_j) includes the jump at t_j.
        """
        t_out = np.asarray(t_out, float)
        u = np.zeros((t_out.size, self.n_elem + 1))
        for tj, dq in loads:
            mask = t_out >= tj
            if not mask.any():
                continue
            decay = self._free_decay(np.full(self.n_elem, float(dq)), t_out[mask] - tj).T
            u[mask, 1:] += decay
        return u

    def settlement(self, loads, t_out):
        """s(t) = int m_v (q - u) dz in metres; right-continuous at load times."""
        t_out = np.asarray(t_out, float)
        u = self.pressure(loads, t_out)
        q = np.zeros(t_out.size)
        for tj, dq in loads:
            q += dq * (t_out >= tj)
        return q * self.mv_int_total - u @ self.g

    def pressure_at_depth(self, loads, t_out, depth):
        """Nodal pressure at a depth that lies on the mesh (all protocol meshes)."""
        idx = int(round(depth / self.h))
        if abs(idx * self.h - depth) > 1e-12:
            raise ValueError("requested depth is not a mesh node")
        return self.pressure(loads, t_out)[:, idx]


# --- Analytical reference (TEST/limit use only, never for observations) --------
def analytical_homogeneous_settlement(t, q_total=50.0, mv=3.0e-4, cv_m2_yr=4.0, h=H_TOTAL):
    tv = (cv_m2_yr / 365.0) * np.asarray(t, float) / h**2
    return mv * q_total * h * rc.terzaghi_average_degree(tv)


def analytical_pressure_ratio(z, t, cv_m2_yr=4.0, h=H_TOTAL, n_terms=500):
    """u(z,t)/q for uniform initial pressure, top drained, base impermeable."""
    z = np.asarray(z, float)
    tv = (cv_m2_yr / 365.0) * max(float(t), 0.0) / h**2
    out = np.zeros_like(z)
    for m in range(n_terms):
        M = np.pi * (2 * m + 1) / 2.0
        out += (2.0 / M) * np.sin(M * z / h) * np.exp(-M * M * tv)
    return out


# --- Convergence study -----------------------------------------------------------
def convergence_study():
    """Homogeneous FE vs analytical on the actual observation days; 40/80/160/320."""
    loads = CASES["homogeneous_50"]["loads"]
    s_ana = analytical_homogeneous_settlement(T_OBS)
    rows = []
    prev_err = None
    for n in CONVERGENCE_MESHES:
        fe = FEConsolidation1D(CASES["homogeneous_50"]["mv"], CASES["homogeneous_50"]["cv_m2_yr"], n)
        s_fe = fe.settlement(loads, T_OBS)
        max_err = float(np.max(np.abs(s_fe - s_ana)))
        # pressure profile error at t = 30 d (interior free nodes)
        u_fe = fe.pressure(loads, np.array([30.0]))[0]
        u_ana = 50.0 * analytical_pressure_ratio(fe.z, 30.0)
        prof = fe.z >= fe.h  # exclude Dirichlet node
        p_rms = float(np.sqrt(np.mean((u_fe[prof] - u_ana[prof]) ** 2)))
        # limits: t=0 (surface Dirichlet early mesh effect) and long time
        s0 = float(fe.settlement(loads, [0.0])[0])
        s0_theory = 50.0 * 3.0e-4 * fe.h / 2.0  # only top surface element contributes
        s_long = float(fe.settlement(loads, [1.0e6])[0])
        rows.append({
            "n_elem": n, "h_m": fe.h,
            "max_settlement_error_m": max_err,
            "rms_pressure_error_kPa_t30": p_rms,
            "refinement_ratio_vs_previous": (prev_err / max_err) if prev_err else float("nan"),
            "s_at_t0_m": s0,
            "s_at_t0_surface_element_theory_m": s0_theory,
            "s_at_1e6d_m": s_long,
            "s_long_time_exact_m": 3.0e-4 * 50.0 * H_TOTAL,
            "meets_tol_5e-4_m": max_err < MAX_SETTLEMENT_ERROR_TOL_M,
        })
        prev_err = max_err
    df = pd.DataFrame(rows)
    # layered self-convergence (no analytical reference): case 3, 160 vs 320
    fe160 = FEConsolidation1D((3.0e-4, 6.0e-4), (4.0, 0.5), 160)
    fe320 = FEConsolidation1D((3.0e-4, 6.0e-4), (4.0, 0.5), 320)
    loads3 = CASES["layered_30_at0_20_at90"]["loads"]
    self_diff = float(np.max(np.abs(fe160.settlement(loads3, T_OBS)
                                    - fe320.settlement(loads3, T_OBS))))
    return df, self_diff


def mesh_acceptance(conv: pd.DataFrame, layered_self_diff: float) -> dict:
    """A-priori production-mesh gate. ALL three conditions must hold:
    (a) homogeneous max settlement error at the production mesh < 5e-4 m;
    (b) last two observed refinement ratios reasonably near 4 (O(h^2));
    (c) layered case-3 max |s_160 - s_320| < 2e-4 m.
    The t=0 nodal surface Dirichlet effect is documented separately in the
    convergence table and does not enter this gate."""
    tol_ok = bool(conv.loc[conv["n_elem"] == PRODUCTION_MESH, "meets_tol_5e-4_m"].iloc[0])
    ratios = conv["refinement_ratio_vs_previous"].to_numpy(float)[-2:]
    lo, hi = REFINEMENT_RATIO_RANGE
    ratio_ok = bool(np.all((ratios > lo) & (ratios < hi)))
    layered_ok = bool(layered_self_diff < LAYERED_SELF_DIFF_TOL_M)
    return {
        "homogeneous_tol_ok": tol_ok,
        "refinement_ratios_last_two": [float(r) for r in ratios],
        "refinement_ratio_range": list(REFINEMENT_RATIO_RANGE),
        "refinement_ratio_ok": ratio_ok,
        "layered_case3_self_diff_m": float(layered_self_diff),
        "layered_case3_tol_m": LAYERED_SELF_DIFF_TOL_M,
        "layered_case3_ok": layered_ok,
        "accepted": bool(tol_ok and ratio_ok and layered_ok),
    }


# --- Homogeneous analytical inversions ------------------------------------------
def design_columns_inversion(form, t, loads, alpha_grid):
    """U-columns per grid rate. history_aware uses the KNOWN prescribed load weights."""
    tv = np.asarray(alpha_grid)[:, None] * np.asarray(t, float)[None, :]
    if form == "single_step" or len(loads) == 1:
        return rc.terzaghi_average_degree(tv)
    q_total = sum(dq for _, dq in loads)
    x = np.zeros_like(tv)
    for tj, dq in loads:
        dt_ = np.maximum(np.asarray(t, float) - tj, 0.0)
        x += (dq / q_total) * rc.terzaghi_average_degree(
            np.asarray(alpha_grid)[:, None] * dt_[None, :])
    return x


def run_inversions(clean_by_case, noise_bank):
    rows = []
    for case_name, case in CASES.items():
        clean = clean_by_case[case_name]
        for cutoff in CUTOFFS:
            cal_mask = T_OBS <= cutoff
            later_mask = np.isin(T_OBS, LATER_DAYS)
            forms = INVERSION_FORMS if len(case["loads"]) > 1 else ("single_step",)
            for form in forms:
                x_cal = design_columns_inversion(form, T_OBS[cal_mask], case["loads"], ALPHA_GRID)
                x_late = design_columns_inversion(form, T_OBS[later_mask], case["loads"], ALPHA_GRID)
                for real in range(N_REAL):
                    y = clean + noise_bank[real]
                    a, sse = rc.profile_nnls_1col(x_cal.T, y[cal_mask])
                    i = int(np.argmin(sse))
                    scale = max(float(y[cal_mask] @ y[cal_mask]), 1e-12)
                    plateau = float(sse[0] - sse[i]) <= 1e-10 * scale
                    pred_cal = a[i] * x_cal[i]
                    pred_late = a[i] * x_late[i]
                    err_late = pred_late - y[later_mask]
                    alpha_hat = float(ALPHA_GRID[i])
                    rows.append({
                        "case": case_name, "cutoff_day": cutoff, "inversion": form,
                        "realization": real, "noise_free": real == 0,
                        "alpha_hat_tv_per_day": alpha_hat,
                        "cv_effective_hat_m2_yr": alpha_hat * H_TOTAL**2 * 365.0,
                        "amplitude_hat_m": float(a[i]),
                        "n_calibration_points": int(cal_mask.sum()),
                        "calibration_rmse_m": float(np.sqrt(np.mean((pred_cal - y[cal_mask]) ** 2))),
                        "later_rmse_m": float(np.sqrt(np.mean(err_late**2))),
                        "later_mean_signed_error_m": float(np.mean(err_late)),
                        "final_day1825_error_m": float(err_late[-1]),
                        "rate_at_grid_low_bound": i == 0,
                        "rate_at_grid_high_bound": i == ALPHA_GRID.size - 1,
                        "low_rate_objective_plateau": plateau,
                        "status": ("bound_low" if i == 0 else "bound_high" if i == ALPHA_GRID.size - 1
                                   else "plateau" if plateau else "ok"),
                    })
    return pd.DataFrame(rows)


def summarize(df):
    noisy = df[df["realization"] > 0]
    summ = noisy.groupby(["case", "cutoff_day", "inversion"]).agg(
        cv_eff_median_m2_yr=("cv_effective_hat_m2_yr", "median"),
        cv_eff_q25=("cv_effective_hat_m2_yr", lambda s: float(s.quantile(0.25))),
        cv_eff_q75=("cv_effective_hat_m2_yr", lambda s: float(s.quantile(0.75))),
        amplitude_median_m=("amplitude_hat_m", "median"),
        later_rmse_median_m=("later_rmse_m", "median"),
        later_signed_bias_median_m=("later_mean_signed_error_m", "median"),
        final_error_median_m=("final_day1825_error_m", "median"),
        n_bound_low=("rate_at_grid_low_bound", "sum"),
        n_bound_high=("rate_at_grid_high_bound", "sum"),
        n_plateau=("low_rate_objective_plateau", "sum"),
        n_noisy=("realization", "count"),
    ).reset_index()
    nf = df[df["noise_free"]][["case", "cutoff_day", "inversion", "cv_effective_hat_m2_yr",
                               "amplitude_hat_m", "later_rmse_m", "later_mean_signed_error_m"]].rename(
        columns={"cv_effective_hat_m2_yr": "cv_eff_noise_free_m2_yr",
                 "amplitude_hat_m": "amplitude_noise_free_m",
                 "later_rmse_m": "later_rmse_noise_free_m",
                 "later_mean_signed_error_m": "later_signed_bias_noise_free_m"})
    return summ.merge(nf, on=["case", "cutoff_day", "inversion"])


# --- Noiseless parameter mesh sensitivity (diagnostic, not mesh shopping) ----
def mesh_sensitivity_study():
    """Noiseless homogeneous + layered two-step inversions at meshes 80/160/320,
    both windows, same free-amplitude grid. Response convergence does NOT
    guarantee parameter convergence on a flat valley; exported per-mesh rates,
    amplitudes and later errors make that visible."""
    rows = []
    for n in MESH_SENSITIVITY_MESHES:
        for case_name in MESH_SENSITIVITY_CASES:
            case = CASES[case_name]
            fe = FEConsolidation1D(case["mv"], case["cv_m2_yr"], n)
            clean = fe.settlement(case["loads"], T_OBS)
            forms = INVERSION_FORMS if len(case["loads"]) > 1 else ("single_step",)
            for cutoff in CUTOFFS:
                cal_mask = T_OBS <= cutoff
                later_mask = np.isin(T_OBS, LATER_DAYS)
                for form in forms:
                    x_cal = design_columns_inversion(form, T_OBS[cal_mask], case["loads"], ALPHA_GRID)
                    x_late = design_columns_inversion(form, T_OBS[later_mask], case["loads"], ALPHA_GRID)
                    a, sse = rc.profile_nnls_1col(x_cal.T, clean[cal_mask])
                    i = int(np.argmin(sse))
                    err_late = a[i] * x_late[i] - clean[later_mask]
                    rows.append({
                        "n_elem": n, "case": case_name, "cutoff_day": cutoff,
                        "inversion": form,
                        "alpha_hat_tv_per_day": float(ALPHA_GRID[i]),
                        "cv_effective_hat_m2_yr": float(ALPHA_GRID[i]) * H_TOTAL**2 * 365.0,
                        "amplitude_hat_m": float(a[i]),
                        "later_rmse_m": float(np.sqrt(np.mean(err_late**2))),
                        "final_day1825_error_m": float(err_late[-1]),
                        "rate_at_grid_low_bound": i == 0,
                        "rate_at_grid_high_bound": i == ALPHA_GRID.size - 1,
                    })
    return pd.DataFrame(rows)


# --- Known-amplitude control (homogeneous case only) ---------------------------
def known_amplitude_control(clean, noise_bank, amplitude=KNOWN_AMPLITUDE_M):
    """Homogeneous case with the total amplitude FIXED at prescribed m_v q H.

    Deliberately supplied exact synthetic information to expose amplitude-rate
    confounding; NOT a claim of field feasibility or of an independently
    measurable amplitude. Same observations, rate grid and windows as the
    free-amplitude inversion: one scalar SSE grid per realization."""
    loads = CASES["homogeneous_50"]["loads"]
    rows = []
    for cutoff in CUTOFFS:
        cal_mask = T_OBS <= cutoff
        later_mask = np.isin(T_OBS, LATER_DAYS)
        x_cal = design_columns_inversion("single_step", T_OBS[cal_mask], loads, ALPHA_GRID)
        x_late = design_columns_inversion("single_step", T_OBS[later_mask], loads, ALPHA_GRID)
        for real in range(N_REAL):
            y = clean + noise_bank[real]
            sse = np.sum((amplitude * x_cal - y[cal_mask][None, :]) ** 2, axis=1)
            i = int(np.argmin(sse))
            err_late = amplitude * x_late[i] - y[later_mask]
            rows.append({
                "case": "homogeneous_50", "cutoff_day": cutoff,
                "inversion": "single_step_known_amplitude",
                "realization": real, "noise_free": real == 0,
                "alpha_hat_tv_per_day": float(ALPHA_GRID[i]),
                "cv_effective_hat_m2_yr": float(ALPHA_GRID[i]) * H_TOTAL**2 * 365.0,
                "amplitude_fixed_m": float(amplitude),
                "n_calibration_points": int(cal_mask.sum()),
                "calibration_rmse_m": float(
                    np.sqrt(np.mean((amplitude * x_cal[i] - y[cal_mask]) ** 2))),
                "later_rmse_m": float(np.sqrt(np.mean(err_late**2))),
                "later_mean_signed_error_m": float(np.mean(err_late)),
                "final_day1825_error_m": float(err_late[-1]),
                "rate_at_grid_low_bound": i == 0,
                "rate_at_grid_high_bound": i == ALPHA_GRID.size - 1,
                "status": ("bound_low" if i == 0 else "bound_high" if i == ALPHA_GRID.size - 1
                           else "ok"),
            })
    return pd.DataFrame(rows)


def summarize_known_amplitude(known: pd.DataFrame, free: pd.DataFrame) -> pd.DataFrame:
    """Per-window comparison of known-A vs free-A rates on identical observations."""
    free_h = free[(free["case"] == "homogeneous_50") & (free["realization"] > 0)]
    rows = []
    for cutoff in CUTOFFS:
        k = known[(known["cutoff_day"] == cutoff) & (known["realization"] > 0)].sort_values("realization")
        f = free_h[free_h["cutoff_day"] == cutoff].sort_values("realization")
        ratio = k["alpha_hat_tv_per_day"].to_numpy() / f["alpha_hat_tv_per_day"].to_numpy()
        rows.append({
            "cutoff_day": cutoff,
            "n_noisy": int(len(k)),
            "amplitude_fixed_m": KNOWN_AMPLITUDE_M,
            "cv_knownA_median_m2_yr": float(k["cv_effective_hat_m2_yr"].median()),
            "cv_knownA_q25_m2_yr": float(k["cv_effective_hat_m2_yr"].quantile(0.25)),
            "cv_knownA_q75_m2_yr": float(k["cv_effective_hat_m2_yr"].quantile(0.75)),
            "cv_freeA_median_m2_yr": float(f["cv_effective_hat_m2_yr"].median()),
            "cv_freeA_q25_m2_yr": float(f["cv_effective_hat_m2_yr"].quantile(0.25)),
            "cv_freeA_q75_m2_yr": float(f["cv_effective_hat_m2_yr"].quantile(0.75)),
            "rate_ratio_knownA_over_freeA_median": float(np.median(ratio)),
            "rate_ratio_knownA_over_freeA_q25": float(np.quantile(ratio, 0.25)),
            "rate_ratio_knownA_over_freeA_q75": float(np.quantile(ratio, 0.75)),
            "later_rmse_knownA_median_m": float(k["later_rmse_m"].median()),
            "later_rmse_freeA_median_m": float(f["later_rmse_m"].median()),
            "n_knownA_bound_low": int(k["rate_at_grid_low_bound"].sum()),
            "n_knownA_bound_high": int(k["rate_at_grid_high_bound"].sum()),
            "n_freeA_bound_low": int(f["rate_at_grid_low_bound"].sum()),
            "n_freeA_bound_high": int(f["rate_at_grid_high_bound"].sum()),
        })
    return pd.DataFrame(rows)


def protocol_dict():
    return {
        "scope": "v2 Part B independent FE semidiscrete forward benchmark (synthetic)",
        "generator": {
            "equation": "m_v du/dt = d/dz[(k/gamma_w) du/dz] + m_v dq/dt",
            "bc": "top drained u=0 at z=0; base no-flow at z=6 m; interface pressure/flux continuity by assembly",
            "elements": "1D linear; consistent mass m_v h/6[[2,1],[1,2]]; conductivity (k/gamma_w)/h[[1,-1],[-1,1]]",
            "propagation": "exact modal propagation of the SEMIDISCRETE system via scipy.linalg.eigh(K,M); no time-discretization error",
            "loads": "instant uniform jumps raise undrained free-node pressure; linear superposition of prescribed steps",
            "settlement": "s = int m_v (q - u) dz in metres (exact for piecewise-linear u)",
            "analytical_terzaghi": "used ONLY for homogeneous-limit convergence tests, never to generate observations",
            "surface_dirichlet_effect": "u(top)=0 at t=0+ gives an O(h) settlement offset of q m_v h/2; documented and convergence-tested",
        },
        "geometry": {"H_total_m": H_TOTAL, "layers_m": [H_LAYER, H_LAYER], "interface_on_mesh": True},
        "properties_synthetic_not_site": {
            "homogeneous": {"mv_1_per_kPa": 3.0e-4, "cv_m2_yr": 4.0},
            "layered": {"top": {"mv": 3.0e-4, "cv_m2_yr": 4.0}, "bottom": {"mv": 6.0e-4, "cv_m2_yr": 0.5}},
            "k_over_gamma_w": "m_v cv/365 in m^2/(kPa day); gamma_w = 9.81 kPa/m if k needed",
        },
        "cases": {k: {"loads_kPa": list(v["loads"]), "note": v["note"]} for k, v in CASES.items()},
        "observation_days": T_OBS.tolist(),
        "cutoffs_day": list(CUTOFFS),
        "common_later_days": LATER_DAYS.tolist(),
        "inversions": {
            "single_step": "s = A U(alpha t), A >= 0 NNLS-profiled over common rate grid",
            "history_aware": "s = A sum_j w_j U(alpha (t - t_j)), KNOWN prescribed weights w_j = dq_j/q_total",
            "alpha_grid_tv_per_day": {"type": "geomspace(1e-6, 3e-2, 2001) + exact homogeneous truth rate",
                                      "n": int(ALPHA_GRID.size)},
            "cv_reporting": "cv_hat = alpha H^2 365; EFFECTIVE for layered cases, no 'true recovered cv'",
            "flags": "grid bound hits and 1e-10 low-rate objective plateaus recorded per row",
        },
        "noise": {"sigma_m": SIGMA_NOISE_M, "n_realizations": N_REAL, "index0": "noiseless",
                  "seed": SEED, "pairing": "common random numbers across cases per realization index"},
        "mesh": {"convergence_meshes": list(CONVERGENCE_MESHES),
                 "selection_rule": (f"production mesh {PRODUCTION_MESH} accepted only if ALL of: "
                                    f"(a) homogeneous max settlement error < {MAX_SETTLEMENT_ERROR_TOL_M} m "
                                    "(comfortably below 2 mm); (b) last two observed refinement ratios "
                                    f"reasonably near 4 in {REFINEMENT_RATIO_RANGE}; (c) layered case-3 max "
                                    f"|s_160 - s_320| < {LAYERED_SELF_DIFF_TOL_M} m. Any violation fails the run."),
                 "layered_self_convergence": "case 3 max |s_160 - s_320| gated, not just reported",
                 "t0_surface_effect": "t=0 nodal surface Dirichlet effect documented in the convergence table"},
        "mesh_parameter_sensitivity": {
            "meshes": list(MESH_SENSITIVITY_MESHES), "cases": list(MESH_SENSITIVITY_CASES),
            "windows_day": list(CUTOFFS), "noise": "none (noiseless)",
            "note": ("per-mesh rates/amplitudes/later errors on the same free-amplitude grid; "
                     "response convergence does NOT guarantee parameter convergence on a flat valley; "
                     "diagnostic, not a search for a flattering mesh"),
        },
        "known_amplitude_control": {
            "scope": "homogeneous_50 only",
            "amplitude_fixed_m": KNOWN_AMPLITUDE_M,
            "amplitude_origin": "prescribed m_v q H -- deliberately supplied EXACT synthetic information",
            "purpose": "expose amplitude-rate confounding against the free-amplitude inversion on identical observations",
            "not_a_claim": "NOT a claim of field feasibility or of an independently measurable amplitude",
            "design": ("scalar SSE over the same ALPHA_GRID; same seed 20260930 noise bank; "
                       "same 29 noisy + 1 clean realizations; same 240/730 windows; mesh 160"),
            "status": "exploratory post-review control, not a preregistered design",
        },
        "pore_pressure_diagnostics": "unused-for-fitting nodal u at depths 1.5/4.5 m exported (mesh nodes on all protocol meshes)",
        "claims": "independently discretized synthetic forward evidence; NOT field validation; "
                  "no matched state-of-the-art coupled-method rerun",
    }


def main():
    rc.RESULTS.mkdir(parents=True, exist_ok=True)
    protocol = protocol_dict()
    print(json.dumps(protocol, indent=2))  # protocol printed BEFORE calculating

    conv, layered_self_diff = convergence_study()
    conv.to_csv(rc.RESULTS / "fe_convergence.csv", index=False)
    gate = mesh_acceptance(conv, layered_self_diff)
    accepted = gate["accepted"]
    print("\nConvergence:\n", conv.to_string(index=False))
    print(f"layered case-3 self-convergence max |s160-s320| = {layered_self_diff:.3e} m")
    print("mesh acceptance gate:", json.dumps(gate, indent=2))
    if not accepted:
        raise RuntimeError(
            f"production mesh {PRODUCTION_MESH} failed the a-priori acceptance gate: {gate}")

    fe = {name: FEConsolidation1D(c["mv"], c["cv_m2_yr"], PRODUCTION_MESH)
          for name, c in CASES.items()}
    clean_by_case = {name: fe[name].settlement(c["loads"], T_OBS) for name, c in CASES.items()}

    obs_rows = []
    for name, c in CASES.items():
        u15 = fe[name].pressure_at_depth(c["loads"], T_OBS, 1.5)
        u45 = fe[name].pressure_at_depth(c["loads"], T_OBS, 4.5)
        for j, d in enumerate(T_OBS):
            obs_rows.append({"case": name, "day": float(d),
                             "settlement_clean_m": float(clean_by_case[name][j]),
                             "u_depth_1p5m_kPa": float(u15[j]),
                             "u_depth_4p5m_kPa": float(u45[j])})
    pd.DataFrame(obs_rows).to_csv(rc.RESULTS / "fe_observations.csv", index=False)

    rng = np.random.default_rng(SEED)
    noise_bank = rng.normal(0.0, SIGMA_NOISE_M, (N_REAL, T_OBS.size))
    noise_bank[0] = 0.0

    inv = run_inversions(clean_by_case, noise_bank)
    inv.to_csv(rc.RESULTS / "fe_inversion_realizations.csv", index=False)
    summ = summarize(inv)
    summ.to_csv(rc.RESULTS / "fe_inversion_summary.csv", index=False)

    mesh_sens = mesh_sensitivity_study()
    mesh_sens.to_csv(rc.RESULTS / "fe_mesh_sensitivity.csv", index=False)

    known = known_amplitude_control(clean_by_case["homogeneous_50"], noise_bank)
    known.to_csv(rc.RESULTS / "fe_known_amplitude_realizations.csv", index=False)
    known_summ = summarize_known_amplitude(known, inv)
    known_summ.to_csv(rc.RESULTS / "fe_known_amplitude_summary.csv", index=False)

    protocol_out = dict(protocol)
    protocol_out["executed"] = {
        "production_mesh": PRODUCTION_MESH,
        "mesh_accepted_by_rule": accepted,
        "mesh_acceptance_gate": gate,
        "homogeneous_max_settlement_error_m": float(
            conv.loc[conv["n_elem"] == PRODUCTION_MESH, "max_settlement_error_m"].iloc[0]),
        "layered_case3_self_convergence_m": layered_self_diff,
        "n_inversion_rows": int(len(inv)),
        "n_mesh_sensitivity_rows": int(len(mesh_sens)),
        "n_known_amplitude_rows": int(len(known)),
    }
    (rc.RESULTS / "fe_protocol.json").write_text(json.dumps(protocol_out, indent=2))

    print("\nInversion summary:\n", summ.to_string(index=False))
    print("\nKnown-amplitude control summary:\n", known_summ.to_string(index=False))


if __name__ == "__main__":
    main()
