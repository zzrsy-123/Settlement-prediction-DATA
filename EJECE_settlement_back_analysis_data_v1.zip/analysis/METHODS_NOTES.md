# Post-review revision calculations: methods notes and manuscript-integration snippets

Scope: all calculations in `analysis/` are **post-review retrospective
comparisons and fixed-scenario diagnostics**. They are not new independent
validation, and no contemporaneous model-selection protocol has been located;
the Ballina log-term choice must be presented as retrospective.

Environment: Python 3.12.14; numpy 2.5.3, scipy 1.16.1, pandas 2.2.3,
matplotlib 3.11.1, openpyxl 3.1.5. Legacy forward code reused by import
(`run_ballina_v14`). The old 60-term Terzaghi routine is retained only for
regression diagnostics; scientific calculations use the converged 500-term
response with exact zero at nonpositive time and no positive-time tail subtraction.

## 1. Ballina same-window comparison (task1)

Training = the six informative increments between the day-58 anchor and day
215 (76, 92, 117, 152, 191, 215 d); evaluation = all 11 later observations
(243-974 d). Rate grid geomspace(1e-4, 1, 6001) /day (legacy grid);
hyperbolic shape grid geomspace(1e-3, 1e3, 4001). Amplitudes fitted by NNLS
(nonnegativity only; zero-bound hits flagged per row). Table:
`ballina_model_comparison.csv`; per-point predictions:
`ballina_per_point_predictions.csv`.

Holdout RMSE / final-day-974 bias (215 d cutoff, metres):

| model | holdout RMSE | holdout MAE | final bias |
|---|---|---|---|
| primary only | 0.2490 | 0.2181 | -0.4120 |
| exp + log1p(dt/58) | 0.0338 | 0.0276 | -0.0010 |
| exp + sqrt(1+dt/58)-1 | 0.1381 | 0.0977 | +0.2701 |
| exp + linear(dt/58) | 0.3519 | 0.2373 | +0.7200 |
| hyperbolic (saturating) | 0.1471 | 0.1312 | -0.2481 |
| Huang et al. Fig.10 "215d" (published forecast) | 0.1034 | 0.1006 | +0.1046 |

The published forecast is extracted at matched observation times from workbook
Fig. 10 and is a published-forecast benchmark, not a rerun and not an
equal-information algorithm race. At the 152 d cutoff all two-amplitude forms
collapse to the primary-only fit (long-term amplitude at its zero bound;
flagged in the CSV) - with four increments and three fitted parameters the
added term is not identifiable, so the log-term "improvement" cannot be
assessed at that window. Each row also carries n_later_points and a
fixed-common 243-974 d RMSE/MAE so the 152/191/215 windows are comparable on
one evaluation set; in the per-point export the day-58 anchor is labelled
`anchor` and is not counted as a holdout point.

## 2. Conditional likelihood/profile analysis (task2)

Fixed assumed error scenarios (not estimated instrument uncertainties).
Absolute-observation covariance C_ij = sigma^2 exp(-|ti-tj|/ell); increment
covariance Cinc(i,j) = Cij - Ci0 - C0j + C00 honours the irregular intervals
and the shared subtracted anchor; the zero anchor is not counted as an
observation. Data and design are whitened by the Cholesky factor and NNLS
amplitudes are profiled over the rate grid. delta-chi2 = 3.841 marks an
approximate conditional 95% likelihood-ratio **support** interval; it is not
validated coverage (fixed assumed covariance, profiled amplitudes, 6-9
points). Tables: `conditional_support_intervals.csv`,
`conditional_profiles.csv`, `conditional_lag1_residual_correlation.csv`.

Ballina exp+log1p support intervals for k (1/day): 0.0138-0.0929 at
sigma=10 mm, ell=30 d; 0.0208-0.0525 at 5 mm, 30 d; upper end truncated at the
grid edge (1.0 /day, flagged) for all 20 mm scenarios. Primary-only support is
much narrower (0.0111-0.0158 at 10 mm, 30 d) - the apparent precision is a
model-form statement, not data information.

Error-model consistency (residual_dof, chi2_per_dof, chi2_dof_95,
error_model_inconsistent are exported per scenario): for Ballina log1p the
5 mm scenarios are inconsistent (chi2/dof = 6.3-27.3, dof = 3), the 10 mm
scenarios give chi2/dof = 1.58-6.83 (ell=0 consistent; ell=30 marginally
above the reference, chi2_min 7.91 vs 7.81, flagged; ell=90 inconsistent),
and the 20 mm scenarios are consistent (chi2/dof = 0.4-1.7) but their upper
support bounds are truncated at the 1 /day grid edge (flagged). Narrow
conditional support under an inconsistent assumed error model is not credible
uncertainty.

Haarajoki natural-ground centreline (Terzaghi vertical response; sigma = 3/6
mm, ell = 0/120 d) uses the original mean Terzaghi series with 500 terms and
exactly zero response for t <= 0; the earlier erroneous subtraction of the
zero-time series tail had created a false low-rate profile bound (parent
audit; initial outputs preserved in qa/series_tail_trial). With the corrected
series the profile minimum sits on a machine-flat low-rate valley and the
lower support bound is grid-truncated at 1e-6 /day in ALL four scenarios
(flagged). Upper support bounds: 5.324e-4 (3 mm, 0 d), 4.759e-4 (3 mm,
120 d), 7.542e-4 (6 mm, 0 d), 6.859e-4 (6 mm, 120 d) /day. The corrected
three-line fit is also unresolved down to the lower search bound (Section 10).
500-vs-1000-term maximum response difference on the actual Haarajoki grid is
0 (full objective profile and both support endpoints converged); U(0)=0,
U(100)=1, pre-loading zero, and the early square-root limit all pass.
chi2_min: 27.796, 93.134, 6.949, 23.283 at dof 7 (nominal 95% reference
14.067); only sigma=6 mm, ell=0 is consistent (chi2/dof 0.99), the 3 mm
scenarios give 3.97 and 13.30, and sigma=6 mm, ell=120 d gives 3.33.
Descriptive lag-one residual correlations (unwhitened residuals): Ballina
log1p -0.60 to -0.54 (n=5 pairs), primary-only -0.24 to -0.16; Haarajoki
+0.69 (ell=0) and +0.93 (ell=120 d) (n=8) - descriptive only, irregular
spacing, not an estimated noise process.

## 3. Joint rate-amplitude contour (task3)

One fixed scenario (sigma=10 mm, ell=30 d); grids k geomspace(5e-3, 0.3, 241),
primary amplitude geomspace(0.02, 1.0, 241) m; the log-term amplitude is
profiled out in whitened space. The delta-chi2 = 5.991 contour is the
approximate two-parameter LR reference region; delta-chi2 = 3.841 is drawn
as a lower objective level, not a two-parameter 95% region. Within the 5.991 region (9775 grid
points) the log-log rate-amplitude correlation is -0.845 with slope -0.965 -
a geometric description of the gridded region, not a posterior correlation.
The region extends over k = 0.0121-0.160 /day and primary amplitude
0.0296-0.594 m: the wide rate support is joint with amplitude compensation
and is hidden when amplitudes are profiled at each rate. Grid:
`joint_objective_grid.csv`; summary: `joint_contour_summary.json`.

## 4. Synthetic model-discrepancy test (task4)

Mean Terzaghi settlement; H = 3 m, cv_true = 4.0 m^2/yr, settlement m, time
days; observations at 7/14/30/60/90/120/180/240/365/500/730 d; fit window
t <= 240 d (8 points), late = 365/500/730 d (3 points); noise iid N(0, 5 mm),
29 noisy realizations + 1 noise-free reference per setting, seed 20260929,
with common random numbers across settings; the exact truth rates are in the
inversion grid. Noise-free recovery is exact (matched 1.0000; de +/-20% ->
1.4400 / 0.6400; wrong boundary -> 4.0000 / 0.2500) ; the paired rate
mappings among the four settings that share one truth response (matched,
de +/-20%, truth-single boundary) are exact per realization, and the
truth-double boundary ratio 4 is exact only in the noise-free reference
(noisy median 4.022). Mean
settlement identifies only cv/H_dr^2, so drainage-length errors map exactly
into cv bias; the early-time sqrt(Tv) rate-amplitude degeneracy is an
asymptotic approximation, and the initial pilot (H = 5 m, cv = 1.2 m^2/yr,
cutoff 180 d) that sat entirely in that regime is preserved in
qa/initial_synthetic/ as a short-window weak-identification result.
Structural late-response biases (noise-free): omitted log secondary -> late
bias +50.8 mm; delayed second load -> late bias -150.7 mm. Their selected
rates (noise-free ratios 0.00156 and 0.00124) sit on unresolved low-rate
plateaus in 29/29 noisy realizations and in the noise-free reference, so
they are plateau values, not identified coefficients. With 5 mm noise the
matched case still shows wide rate scatter (median ratio 0.954, IQR
0.0013-1.257; 3/29 grid-low hits; 8/29 on the numerical low-rate plateau,
defined as the smallest-grid-rate SSE within 1e-10*sum(y_i^2) of the
minimum; the same 8/29 count in the de +/-20% and truth-single-boundary
settings, none in the truth-double boundary setting): early-window
fits remain noise-fragile. Tables: `task4_*`; full specification in
`synthetic_specification.json`. Synthetic discrepancy is not field validation.

## 5. Conditional propagation (task5)

250 simulations per scenario x form; seed 20260929. Absolute errors drawn from
N(0, C_abs) over the 7 observation times, increments carry e_i - e_0; refit
with the Task-2 whitened estimator; unit-cell diameter factor U(0.9, 1.1)
enters both D_cell^2 and Barron F(N); the absolute forecast level is
(s0 + e_0) + model increment with elapsed dt = t - 58 in every response term.
Reported separately per form (no cross-model averaging). 974 d forecast 5-95%
(sigma=10 mm, ell=30 d): log1p 1.23-1.49 m (observed 1.427 m inside), sqrt
1.32-1.83 m, linear 1.54-2.44 m (above the observation). log1p at sigma=20 mm
produces grid-high rate hits with cr_eq 95th percentile up to ~2e2 m^2/yr -
flagged as grid truncation, not physical values (initial buggy run, which
evaluated calendar days as elapsed time and did not propagate the anchor
shift, preserved in qa/initial_propagation/). Across all 27 groups, 70
refits hit the upper rate-grid edge (8 at sigma=10 mm, 62 at sigma=20 mm),
9 hit the lower edge (all log1p at sigma=20 mm), and 271 placed the
long-term amplitude on its zero bound. A loading-factor uncertainty is
not included: amplitudes are freely profiled, so load scale cannot be
separated from the fitted amplitude. Tables: `input_propagation_samples.csv`,
`input_propagation_summary.csv`; the 5-95 spreads are a conditional
input-perturbation sensitivity distribution (Gaussian perturbation of the
observed record), not a sampling distribution or validated
confidence/prediction coverage.

## 6. Task1--5 figures (analysis/figures, 6.3 in wide, base text 11 pt)

- `fig1_task1_model_comparison.pdf/.png` - fits and per-point holdout errors.
- `fig2_task2_conditional_profiles.pdf/.png` - Ballina and Haarajoki profiles.
- `fig3_task3_joint_contour.pdf/.png` - joint rate-amplitude objective.
- `fig4_task4_synthetic_discrepancy.pdf/.png` - rate bias and late error.
- `fig5_task5_propagation.pdf/.png` - per-form forecast and cr_eq spreads.

Manuscript figure names (not included in this data release): `ballina_model_form_comparison.pdf`,
`conditional_rate_profiles.pdf`, `joint_rate_amplitude_contour.pdf`,
`synthetic_model_discrepancy.pdf`, `conditional_propagation_spreads.pdf`
(parent-adjusted: 6.3 in width; fig4 panel a plots the five noise-free
geometry ratios with omitted-secondary/delayed-loading marked 'unresolved
rate', and panel b retains all 29 noisy realizations per setting).

## 7. Verification

Internal regression and repeatability checks were completed before this public release. The checked numerical outputs and protocols are included here; internal test logs and worker reports are omitted.

## 8. Classical and optimizer controls (v2)

`v2_observational_baselines.py`: calibration-only interpolation for Asaoka,
30-day primary resampling with 45/60-day sensitivity, and whole-window
linearized hyperbolic fits. Twelve rows cover the 152/191/215-day cutoffs;
all use the common 11 later dates. At day 215, Asaoka 30/45-day later RMSEs
are 239/215 mm; the 60-day result is 54 mm but has only two fitted pairs.
The linearized hyperbolic RMSE is 147 mm. These are classical controls,
not matched reruns of a modern coupled Bayesian model. A separate 12-start
bounded joint optimizer uses the same logarithmic model, bounds and data
as the profile search. Its best rate is 0.03773321/day (profile 0.03772825);
six starts land at the lower rate bound with zero primary amplitude.
Every outcome and the timing diagnostic are exported; no speed advantage
is inferred. Full formulas/settings: SI S9.

## 9. Independent finite-element generator and amplitude control (v2)

`v2_fe_benchmark.py` solves mv*u_t = d/dz[(k/gamma_w)*u_z] + mv*q_t
using linear finite elements, consistent mass, and the exact semidiscrete
modal solution. Top drainage and no basal flow, H=6 m, layer interface=3 m.
Homogeneous cv=4 m2/year, mv=3e-4/kPa; the lower layer in layered cases
has cv=0.5 and mv=6e-4. k/gamma_w=mv*cv/365. Loads: 50 kPa at day zero,
or 30 then 20 kPa at days zero/90. Ultimate settlements are 0.09/0.135 m,
and the maximum imposed local strain is 3%. Observation/noise/grid details
are exported in `fe_protocol.json` and SI S10.

The main experiment has 240 fits: 30 paired records (one noiseless plus
29 with 2-mm Gaussian noise), 240/730-day calibration windows, three
forward cases and single/history-matched inverse variants for staged loading.
Four common later dates are 900/1200/1500/1825 days. Mesh checks use
40/80/160/320 elements; homogeneous maximum forward errors are
0.1400/0.0356/0.00894/0.00224 mm. Layered staged 160-to-320 difference
is 0.0574 mm. Numerical error from the drained endpoint load jump is
retained and converges; it is not silently corrected against an analytical curve.

Eighteen noiseless inverse mesh checks show why a converged forward response
does not ensure a stable inverse estimate: the homogeneous 240-day free-
amplitude cv changes 10.04/8.13/6.86 m2/year at 80/160/320 elements,
whereas the 730-day values approach 4.117/4.033/4.012. The 60 extra
known-amplitude controls use exactly A=0.09 m and the same observations;
the 29 noisy median cv values are 3.951/4.000 for 240/730-day windows,
with IQR 3.752--4.160 / 3.850--4.096 and no boundary hits. This tests the
value of independent amplitude information under a correct homogeneous model;
it does not establish that the amplitude is known exactly at a real site.
History matching does not uniformly improve later RMSE across noisy cases.

## 10. Corrected three-line Haarajoki calculations

`haarajoki_corrected.py` supersedes the legacy three-line estimates and figures.
The 60-term U(0)=0.003377 residual had penalized large amplitudes and created
an artificial vertical-rate minimum. The corrected 500-term response is
identical to 1000 terms on all actual grids and uses U(0)=0 exactly.
The same data, windows, grids, RMSE definition, and seed-20260805 paired
300 digitization perturbations are preserved. All nine window fits are
exported, plus 900 perturbation fits, propagation, mapping, and two-term
long-term sensitivities. SI S4 gives the complete updated protocol.

At 24 months, natural-ground rate selection reaches the 1e-6/day lower
bound on a flat valley (1568 tied candidates); its 13.48-mm later RMSE
does not identify cv. All 300 natural-ground perturbations reach that bound.
Radial fits are unchanged: rate 0.002371/day, later RMSE 107.06 mm.
The combined model, with the vertical component fixed at the boundary value,
gives 2.512e-5/day and 54.86 mm, with primary amplitudes about 7.2--7.9 m.
At the upper descriptive vertical endpoint, combined later error becomes
99.39 mm and final bias changes sign. Radial/combined logarithmic variants
give 20.32/15.92 mm; they are exploratory decompositions, not independent
validation. Two adjacent numerically tied candidates in the combined-log
fit alone do not establish broad non-identification; its large primary
amplitude and dependence on the unresolved vertical rate remain substantive.

Internal test logs and worker reports are omitted from this release.
