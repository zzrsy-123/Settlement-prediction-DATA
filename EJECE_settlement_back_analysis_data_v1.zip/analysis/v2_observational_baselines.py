"""V2 Part A: matched-information observational baselines for Ballina.

Adds THREE retrospective observational baselines to the preserved v1
primary/log/sqrt/linear/nonlinear-hyperbola comparison (run_task1):

1. Asaoka (1978) first-order graphical/OLS recurrence  s_j = a + b s_{j-1}
   on an equal-interval grid ENDING at the cutoff and stepping back to >= 58 d.
   Settlement at grid times is LINEARLY INTERPOLATED between observed
   calibration times (including the 58 d anchor); no later data are used and
   the resamples are NOT independent extra observations. This is the
   first-order recurrence form, not Asaoka's Bayesian version.
   Primary interval 30 d; sensitivity 45/60 d. Forecasts are produced only
   for 0 < b < 1; invalid slopes are flagged and retained, never clipped.
   Fits with fewer than 3 pairs are shown as 'insufficient_pairs'.

2. Whole-window linearized hyperbolic comparator (t-58)/(s-s58) = a + b(t-58)
   fitted by OLS on the TRANSFORMED residuals over the whole calibration
   window with positive early increments. This implementation does NOT claim
   the late-linear-segment selection of Tan, Inoue and Lee (1991).

3. Same-model optimizer control at the 215 d cutoff: joint bounded
   scipy least_squares on (log k, a1, a2 >= 0) for the v1 log form, from
   multiple fixed starts, compared with the v1 profiled grid + NNLS result.
   The k bounds EQUAL the rc.K_GRID endpoints (1e-4, 1) and the amplitudes
   are nonnegative with NO artificial upper bound, so the two estimators
   search the same feasible set. Every start is recorded, including
   unsuccessful and active-bound runs; the best candidate is selected only
   from successful finite runs. This is a numerical-equivalence control,
   not a claim of novelty or of superiority over modern coupled
   Bayesian/EVP methods, and the measured wall times are a diagnostic for
   this tiny example only, not an efficiency benchmark.

All fits use ONLY data up to the cutoff; all forms are evaluated on the
common 11 later observations 243-974 d for every cutoff (152/191/215).
All comparisons are post-review retrospective, not new independent validation.

Primary sources (verified by parent; see manuscript bibliography):
  Asaoka (1978) doi:10.3208/sandf1972.18.4_87
  Tan, Inoue and Lee (1991) doi:10.1061/(ASCE)0733-9410(1991)117:11(1723)
"""
from __future__ import annotations

import json
import time

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

import revision_core as rc
import run_task1_ballina_models as t1  # reuse v1 fit/predict helpers (read-only)

CUTOFFS = (152, 191, 215)
DT_INTERVALS = (30, 45, 60)
MIN_PAIRS = 3
LATER_FROM_DAY = 215  # common later evaluation = 11 dates 243..974 for all cutoffs


# --- Asaoka first-order recurrence -------------------------------------------
def asaoka_grid_times(cutoff: float, dt: float, anchor: float = rc.T0_DAY) -> np.ndarray:
    """Equal-interval grid ending exactly at cutoff, stepping back until >= anchor."""
    pts = []
    t = float(cutoff)
    while t >= anchor - 1e-12:
        pts.append(t)
        t -= dt
    return np.array(pts[::-1], dtype=float)


def _validate_calibration_slice(t_obs: np.ndarray, s_obs: np.ndarray, cutoff: float):
    """Validate the CALIBRATION slice only (anchor..cutoff); later data never reach here."""
    if t_obs.size < 2:
        raise ValueError(f"need >= 2 calibration observations, got {t_obs.size}")
    if not (np.all(np.isfinite(t_obs)) and np.all(np.isfinite(s_obs))):
        raise ValueError("calibration times and readings must be finite")
    if not np.all(np.diff(t_obs) > 0.0):
        raise ValueError("calibration times must be strictly increasing")
    lo, hi = float(t_obs[0]), float(t_obs[-1])
    if not (lo - 1e-12 <= rc.T0_DAY <= hi + 1e-12 and lo - 1e-12 <= cutoff <= hi + 1e-12):
        raise ValueError(
            f"anchor ({rc.T0_DAY}) and cutoff ({cutoff}) must lie inside the calibrated "
            f"support [{lo:g}, {hi:g}]; interpolation would otherwise extrapolate")


def fit_asaoka(day: np.ndarray, settlement: np.ndarray, cutoff: float, dt: float) -> dict:
    """OLS fit of s_j = a + b s_{j-1} on linearly interpolated equal-interval values.

    Interpolation is restricted to observed calibration times (anchor..cutoff);
    any configuration that would extrapolate raises instead of silently using
    np.interp end values. Returns fitted coefficients (unclipped), counts and
    status flags.
    """
    if not (np.isfinite(dt) and dt > 0.0):
        raise ValueError(f"dt must be positive and finite, got {dt}")
    if not (np.isfinite(cutoff) and cutoff > 0.0):
        raise ValueError(f"cutoff must be positive and finite, got {cutoff}")
    cal = (day >= rc.T0_DAY) & (day <= cutoff)
    t_obs, s_obs = day[cal], settlement[cal]
    _validate_calibration_slice(t_obs, s_obs, cutoff)
    grid = asaoka_grid_times(cutoff, dt)
    if grid[0] < t_obs[0] - 1e-12 or grid[-1] > t_obs[-1] + 1e-12:
        raise ValueError("Asaoka grid outside observed calibration support")
    s_g = np.interp(grid, t_obs, s_obs)
    n_pairs = grid.size - 1
    x, y = s_g[:-1], s_g[1:]
    if n_pairs >= 2 and np.std(x) > 0:
        b, a = np.polyfit(x, y, 1)
    else:  # cannot fit a slope at all
        a, b = float("nan"), float("nan")
    flags = []
    if n_pairs < 2:
        flags.append("cannot_fit_slope")
    elif n_pairs < MIN_PAIRS:
        flags.append("insufficient_pairs")
    if np.isfinite(b):
        if b <= 0.0:
            flags.append("invalid_nonconsolidating_slope")
        elif b >= 1.0:
            flags.append("invalid_nonconverging_slope")
    admissible = np.isfinite(b) and 0.0 < b < 1.0
    s_inf = a / (1.0 - b) if admissible else float("nan")
    rate = -np.log(b) / dt if admissible else float("nan")
    return {
        "model": f"asaoka_dt{dt}",
        "cutoff_day": cutoff,
        "interval_day": dt,
        "n_original": int(cal.sum()),
        "n_resampled": int(grid.size),
        "n_pairs": int(n_pairs),
        "a_m": float(a),
        "b": float(b),
        "s_inf_m": float(s_inf),
        "rate_per_day": float(rate),
        "s_cutoff_resampled_m": float(s_g[-1]),
        "admissible": bool(admissible),
        "status": ";".join(flags) if flags else "ok",
        "grid_times_day": ";".join(f"{g:g}" for g in grid),
        "_grid": grid,
        "_s_grid": s_g,
    }


def predict_asaoka(fit: dict, times: np.ndarray) -> np.ndarray:
    """Fitted exponential curve anchored at the resampled cutoff observation."""
    if not fit["admissible"]:
        return np.full(times.shape, np.nan)
    b, dt, cutoff = fit["b"], fit["interval_day"], fit["cutoff_day"]
    return fit["s_inf_m"] + (fit["s_cutoff_resampled_m"] - fit["s_inf_m"]) * b ** ((times - cutoff) / dt)


# --- Whole-window linearized hyperbolic comparator ----------------------------
def fit_linearized_hyperbola(day: np.ndarray, settlement: np.ndarray, s0: float,
                             cutoff: float) -> dict:
    """OLS on transformed residuals z = (t-58)/(s-s58) = a + b(t-58), whole window.

    Positive early increments only. Positivity and pole checks are reported.
    Whole-window implementation: does NOT claim Tan et al.'s late-segment selection.
    """
    cal = (day > rc.T0_DAY) & (day <= cutoff)
    x = day[cal] - rc.T0_DAY
    y = settlement[cal] - s0
    pos = y > 0
    x, y = x[pos], y[pos]
    n_used = int(pos.sum())
    if n_used < 2 or np.unique(x).size < 2:
        return {
            "model": "linearized_hyperbola",
            "cutoff_day": cutoff,
            "n_window": int(cal.sum()),
            "n_used_positive": n_used,
            "a_day_per_m": float("nan"),
            "b_per_m": float("nan"),
            "s_inf_m": float("nan"),
            "pole_elapsed_day": float("nan"),
            "admissible": False,
            "status": "insufficient_points",
            "fitting": "OLS on transformed residuals (t-58)/(s-s58); whole calibration window",
        }
    z = x / y
    b, a = np.polyfit(x, z, 1)  # z = a + b x
    flags = []
    if n_used != int(cal.sum()):
        flags.append("nonpositive_increment_dropped")
    if a <= 0.0:
        flags.append("invalid_nonpositive_intercept")
    if b <= 0.0:
        flags.append("invalid_nonpositive_slope")
    pole_x = -a / b if b != 0 else float("nan")
    x_max = 974.0 - rc.T0_DAY
    if np.isfinite(pole_x) and pole_x > 0.0 and pole_x <= x_max:
        flags.append("pole_inside_forecast_range")
    admissible = a > 0.0 and b > 0.0 and "pole_inside_forecast_range" not in flags
    return {
        "model": "linearized_hyperbola",
        "cutoff_day": cutoff,
        "n_window": int(cal.sum()),
        "n_used_positive": n_used,
        "a_day_per_m": float(a),
        "b_per_m": float(b),
        "s_inf_m": float(s0 + 1.0 / b) if b > 0 else float("nan"),
        "pole_elapsed_day": float(pole_x),
        "admissible": bool(admissible),
        "status": ";".join(flags) if flags else "ok",
        "fitting": "OLS on transformed residuals (t-58)/(s-s58); whole calibration window",
    }


def predict_linearized_hyperbola(fit: dict, times: np.ndarray, s0: float) -> np.ndarray:
    if not fit["admissible"]:
        return np.full(times.shape, np.nan)
    x = np.maximum(times - rc.T0_DAY, 0.0)
    return s0 + x / (fit["a_day_per_m"] + fit["b_per_m"] * x)


# --- Same-model optimizer control (215 d, v1 log form) ------------------------
K_LO, K_HI = float(rc.K_GRID[0]), float(rc.K_GRID[-1])  # 1e-4, 1 (shared feasible set)


def optimizer_control(day: np.ndarray, settlement: np.ndarray, s0: float, cutoff: float = 215):
    """Joint bounded least_squares on (log k, a1, a2 >= 0), multiple fixed starts,
    compared with the v1 profiled grid + NNLS log-form fit at the same cutoff.

    k bounds EQUAL the rc.K_GRID endpoints (1e-4, 1); amplitudes are nonnegative
    with no artificial upper bound, so both estimators search the same feasible
    set. ALL starts are recorded (never discarded); the best candidate uses only
    successful finite runs and raises if none exist."""
    train, _ = rc.ballina_train_later(day, cutoff)
    dt = day[train] - rc.T0_DAY
    y = settlement[train] - s0

    def residuals(theta):
        k = np.exp(theta[0])
        return theta[1] * (1.0 - np.exp(-k * dt)) + theta[2] * np.log1p(dt / rc.T0_DAY) - y

    bounds = ([np.log(K_LO), 0.0, 0.0], [np.log(K_HI), np.inf, np.inf])
    rows = []
    for k0 in (1e-3, 5e-3, 2e-2, 1e-1):
        for a0 in (0.1, 0.5, 1.0):
            t_start = time.perf_counter()
            opt = least_squares(residuals, [np.log(k0), a0, a0], bounds=bounds,
                                method="trf", xtol=1e-14, ftol=1e-14, gtol=1e-14)
            wall_ms = (time.perf_counter() - t_start) * 1e3
            k_hat = float(np.exp(opt.x[0]))
            rows.append({
                "cutoff_day": cutoff,
                "start_k": k0, "start_a1": a0, "start_a2": a0,
                "success": bool(opt.success),
                "solver_status": int(opt.status),
                "solver_message": str(opt.message),
                "optimality": float(opt.optimality),
                "objective_sse_m2": float(2.0 * opt.cost),
                "k_day_inverse": k_hat,
                "a1_m": float(opt.x[1]),
                "a2_m": float(opt.x[2]),
                "nfev": int(opt.nfev),
                "wall_time_ms": wall_ms,
                "k_at_lower_bound": bool(k_hat <= K_LO * 1.0001),
                "k_at_upper_bound": bool(k_hat >= K_HI / 1.0001),
                "a1_at_lower_bound": bool(opt.x[1] <= 1e-10),
                "a2_at_lower_bound": bool(opt.x[2] <= 1e-10),
            })
    starts = pd.DataFrame(rows)
    candidates = starts[starts["success"] & np.isfinite(starts["objective_sse_m2"])]
    if candidates.empty:
        raise RuntimeError("optimizer control: no successful finite least_squares candidate")
    best = candidates.loc[candidates["objective_sse_m2"].idxmin()]

    grid_fit = t1.fit_form(dt, y, "log1p", rc.K_GRID)
    step = rc.K_GRID[1] / rc.K_GRID[0]
    comparison = {
        "cutoff_day": cutoff,
        "feasible_set": (f"k in [{K_LO:g}, {K_HI:g}] (exact rc.K_GRID endpoints), "
                         "a1, a2 in [0, inf) (nonnegative, no artificial upper bound)"),
        "n_starts": int(len(starts)),
        "n_successful": int(len(candidates)),
        "n_unsuccessful": int(len(starts) - len(candidates)),
        "best_selected_from": "successful finite candidates only; ALL starts retained in the CSV",
        "grid_sse_m2": grid_fit["sse"],
        "grid_k_day_inverse": grid_fit["grid_value"],
        "joint_best_sse_m2": float(best["objective_sse_m2"]),
        "joint_best_k_day_inverse": float(best["k_day_inverse"]),
        "sse_difference_joint_minus_grid_m2": float(best["objective_sse_m2"] - grid_fit["sse"]),
        "k_within_one_grid_step": bool(
            abs(np.log(best["k_day_inverse"] / grid_fit["grid_value"])) <= np.log(step) + 1e-9),
        "numerically_equivalent_within_grid_resolution": bool(
            best["objective_sse_m2"] <= grid_fit["sse"] + 1e-12
            and abs(np.log(best["k_day_inverse"] / grid_fit["grid_value"])) <= np.log(step) + 1e-9),
        "interpretation": ("numerical-equivalence control for the same model and data; "
                           "not a claim of novelty or superiority over modern coupled methods; "
                           "measured wall times are a diagnostic for this tiny example only, "
                           "not an efficiency benchmark"),
    }
    return starts, comparison


# --- Shared evaluation ---------------------------------------------------------
def metrics(obs: np.ndarray, pred: np.ndarray):
    r = pred - obs
    return float(np.sqrt(np.nanmean(r**2))), float(np.nanmean(np.abs(r))), float(r[-1])


def main():
    rc.RESULTS.mkdir(parents=True, exist_ok=True)
    day, settlement, s0, _ = rc.load_ballina()
    later_common = day > LATER_FROM_DAY

    protocol = {
        "scope": "v2 Part A matched-information observational baselines (retrospective)",
        "anchor_day": rc.T0_DAY,
        "cutoffs_day": list(CUTOFFS),
        "asaoka": {
            "intervals_day": list(DT_INTERVALS),
            "primary_interval_day": 30,
            "grid_rule": "equal intervals ending exactly at cutoff, stepping back until >= 58 d",
            "interpolation": "linear, ONLY inside observed calibration times incl. 58 d anchor; no later data",
            "validation": ("dt/cutoff positive finite; >= 2 calibration observations; strictly increasing "
                           "finite times and finite readings; anchor and cutoff inside calibrated support; "
                           "any extrapolating configuration raises (no silent np.interp end values); "
                           "only the calibration slice is assessed, later observations never influence fits"),
            "resamples_note": "resampled values are interpolates, NOT independent extra observations",
            "form": "first-order graphical/OLS recurrence s_j = a + b s_{j-1} (not Asaoka's Bayesian version)",
            "min_pairs_for_point_fit": MIN_PAIRS,
            "invalid_slopes": "flagged and retained, never clipped; forecasts only for 0 < b < 1",
            "source": "Asaoka (1978) doi:10.3208/sandf1972.18.4_87",
        },
        "linearized_hyperbola": {
            "transform": "(t-58)/(s-s58) = a + b(t-58), OLS on transformed residuals, whole window",
            "increments": "positive early increments only",
            "insufficient_points": "explicit 'insufficient_points' status when < 2 positive distinct times; no polyfit crash",
            "segment_selection": "none; does NOT claim the late-linear-segment selection of Tan et al. (1991)",
            "source": "Tan, Inoue and Lee (1991) doi:10.1061/(ASCE)0733-9410(1991)117:11(1723)",
        },
        "optimizer_control": {
            "cutoff_day": 215, "form": "v1 log1p", "solver": "scipy least_squares (trf), bounded",
            "parameters": "k in [1e-4, 1] (exact rc.K_GRID endpoints), amplitudes in [0, inf)",
            "starts": "fixed: k0 in {1e-3,5e-3,2e-2,1e-1} x a0 in {0.1,0.5,1.0}",
            "runs": "ALL starts recorded incl. unsuccessful/active-bound runs; best from successful finite only",
            "comparison": "numerical equivalence with v1 profiled grid+NNLS; no novelty/superiority claim; not an efficiency benchmark",
        },
        "evaluation": {
            "calibration": "RMSE on original calibration increments (anchor excluded)",
            "later": "common 11 later observations 243-974 d for ALL cutoffs: RMSE/MAE/final-day974 bias",
            "status": "post-review retrospective baselines; not new independent validation",
        },
        "v1_preserved": "run_task1 v1 comparisons untouched; v2 models are additions only",
    }
    print(json.dumps(protocol, indent=2))

    fit_rows, pred_rows, summ_rows = [], [], []
    for cutoff in CUTOFFS:
        train, _ = rc.ballina_train_later(day, cutoff)
        for dt in DT_INTERVALS:
            fit = fit_asaoka(day, settlement, cutoff, dt)
            pred_all = predict_asaoka(fit, day)
            fit_rows.append({k: v for k, v in fit.items() if not k.startswith("_")})
            _emit(fit["model"], cutoff, fit["admissible"], pred_all,
                  day, settlement, train, later_common, fit_rows, pred_rows, summ_rows, fit)
        fit_h = fit_linearized_hyperbola(day, settlement, s0, cutoff)
        pred_h = predict_linearized_hyperbola(fit_h, day, s0)
        fit_rows.append(fit_h)
        _emit(fit_h["model"], cutoff, fit_h["admissible"], pred_h,
              day, settlement, train, later_common, fit_rows, pred_rows, summ_rows, fit_h)

    starts, comparison = optimizer_control(day, settlement, s0)
    starts.to_csv(rc.RESULTS / "optimizer_control_starts.csv", index=False)
    (rc.RESULTS / "optimizer_control_comparison.json").write_text(json.dumps(comparison, indent=2))

    pd.DataFrame(fit_rows).to_csv(rc.RESULTS / "observational_model_fits.csv", index=False)
    pd.DataFrame(pred_rows).to_csv(rc.RESULTS / "observational_models_predictions.csv", index=False)
    pd.DataFrame(summ_rows).to_csv(rc.RESULTS / "observational_summary_errors.csv", index=False)
    (rc.RESULTS / "observational_protocol.json").write_text(json.dumps(protocol, indent=2))

    print(pd.DataFrame(summ_rows).to_string(index=False))
    print("\nOptimizer control comparison:", json.dumps(comparison, indent=2))


def _emit(model, cutoff, admissible, pred_all, day, settlement, train, later_common,
          fit_rows, pred_rows, summ_rows, fit):
    rmse_t = float(np.sqrt(np.mean((pred_all[train] - settlement[train]) ** 2))) if admissible else float("nan")
    rmse_l, mae_l, bias_f = metrics(settlement[later_common], pred_all[later_common])
    if not admissible:
        rmse_l = mae_l = bias_f = float("nan")
    for d, p, o in zip(day, pred_all, settlement):
        if d < rc.T0_DAY:
            continue
        split = ("anchor" if d == rc.T0_DAY else "train" if (d > rc.T0_DAY and d <= cutoff)
                 else "later_common_243_974" if d > LATER_FROM_DAY else "post_cutoff_pre_216")
        pred_rows.append({"model": model, "cutoff_day": cutoff, "day": float(d),
                          "observed_m": float(o), "prediction_m": float(p), "split": split})
    summ_rows.append({
        "model": model, "cutoff_day": cutoff,
        "admissible": bool(admissible),
        "status": fit.get("status", ""),
        "n_train_increments": int(train.sum()),
        "train_rmse_m": rmse_t,
        "common_later_rmse_m": rmse_l,
        "common_later_mae_m": mae_l,
        "final_day974_bias_m": bias_f,
        "n_later_points": int(later_common.sum()),
    })


if __name__ == "__main__":
    main()
