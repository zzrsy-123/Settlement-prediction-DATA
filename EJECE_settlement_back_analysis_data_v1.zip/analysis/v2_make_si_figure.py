"""V2 SI figure: known-amplitude control and noiseless parameter mesh dependence.

One 6.3 in wide, 11 pt figure, two stacked panels with outside legends:
(a) effective-cv estimates for the homogeneous synthetic case with the
    amplitude FIXED at the prescribed 0.09 m (deliberately supplied exact
    synthetic information) versus the free-amplitude inversion, on identical
    observations at both windows; log axis, prescribed cv = 4 reference line.
(b) noiseless per-mesh effective-cv estimates at meshes 80/160/320 for the
    homogeneous and layered history-aware inversions at both windows; log
    axis, same reference line.

Exploratory post-review diagnostics, not a preregistered design. No
superiority narrative: the fixed-amplitude case is supplied exact information
unavailable in practice, and later prediction error can stay low even for
extreme amplitude-rate combinations.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

import revision_core as rc

plt.rcParams.update({
    "font.size": 11, "axes.labelsize": 11, "axes.titlesize": 11,
    "xtick.labelsize": 11, "ytick.labelsize": 11, "legend.fontsize": 11,
    "figure.dpi": 200, "savefig.dpi": 600, "lines.linewidth": 1.4,
})
C_FREE, C_FIXED = "#d6604d", "#2166ac"
C_MESH = {"homogeneous 240 d": ("#d6604d", "o", "--"),
          "homogeneous 730 d": ("#d6604d", "s", "-"),
          "layered history-aware 240 d": ("#2166ac", "^", "--"),
          "layered history-aware 730 d": ("#2166ac", "v", "-")}
TRUTH_CV = 4.0


def main():
    rc.FIGURES.mkdir(parents=True, exist_ok=True)
    inv = pd.read_csv(rc.RESULTS / "fe_inversion_realizations.csv")
    known = pd.read_csv(rc.RESULTS / "fe_known_amplitude_realizations.csv")
    mesh = pd.read_csv(rc.RESULTS / "fe_mesh_sensitivity.csv")

    fig, axes = plt.subplots(2, 1, figsize=(6.3, 6.2))

    # --- panel (a): fixed vs free amplitude ------------------------------------
    ax = axes[0]
    free_n = inv[(inv["case"] == "homogeneous_50") & ~inv["noise_free"]]
    known_n = known[~known["noise_free"]]
    nf_free = inv[(inv["case"] == "homogeneous_50") & inv["noise_free"]]
    nf_known = known[known["noise_free"]]
    groups, data, colors, nf_vals = [], [], [], []
    for cutoff in (240.0, 730.0):
        groups += [f"free\n{cutoff:g} d", f"fixed\n{cutoff:g} d"]
        data += [free_n.loc[free_n["cutoff_day"] == cutoff,
                            "cv_effective_hat_m2_yr"].to_numpy(),
                 known_n.loc[known_n["cutoff_day"] == cutoff,
                             "cv_effective_hat_m2_yr"].to_numpy()]
        colors += [C_FREE, C_FIXED]
        nf_vals += [nf_free.loc[nf_free["cutoff_day"] == cutoff,
                                "cv_effective_hat_m2_yr"].iloc[0],
                    nf_known.loc[nf_known["cutoff_day"] == cutoff,
                                 "cv_effective_hat_m2_yr"].iloc[0]]
    pos = np.arange(1, len(groups) + 1)
    bp = ax.boxplot(data, positions=pos, widths=0.55, showfliers=False,
                    patch_artist=True,
                    medianprops={"color": "#1a1a1a", "lw": 1.2},
                    whiskerprops={"color": "#7f7f7f"},
                    capprops={"color": "#7f7f7f"})
    for patch, c in zip(bp["boxes"], colors):
        patch.set(facecolor=c, alpha=0.35, edgecolor=c)
    rng = np.random.default_rng(7)
    for x, y, c in zip(pos, data, colors):
        ax.plot(x + rng.uniform(-0.12, 0.12, y.size), y, "o", ms=3, color=c,
                alpha=0.75, zorder=3)
    ax.plot(pos, nf_vals, "D", ms=5, color="#1a1a1a", ls="none", zorder=4)
    ax.axhline(TRUTH_CV, color="#43931f", lw=1.2, ls=":", zorder=2)
    ax.set_yscale("log")
    ax.set_ylim(1e-2, 1e3)
    ax.set_xticks(pos)
    ax.set_xticklabels(groups)
    ax.set_ylabel("effective $c_v$ (m$^2$/yr)")
    ax.set_title("(a) fixed vs free amplitude", loc="left")
    ax.legend(handles=[Patch(facecolor=C_FREE, alpha=0.35, edgecolor=C_FREE,
                             label="free amplitude"),
                       Patch(facecolor=C_FIXED, alpha=0.35, edgecolor=C_FIXED,
                             label="fixed amplitude $A$ = 0.09 m"),
                       Line2D([0], [0], marker="D", color="none", mfc="#1a1a1a",
                              ms=5, ls="none", label="noiseless"),
                       Line2D([0], [0], color="#43931f", ls=":",
                              label="prescribed $c_v$ = 4")],
              loc="upper center", bbox_to_anchor=(0.5, -0.24), ncols=2,
              frameon=False, fontsize=11)

    # --- panel (b): noiseless mesh dependence -----------------------------------
    ax = axes[1]
    sel = {("homogeneous_50", "single_step", 240.0): "homogeneous 240 d",
           ("homogeneous_50", "single_step", 730.0): "homogeneous 730 d",
           ("layered_30_at0_20_at90", "history_aware", 240.0): "layered history-aware 240 d",
           ("layered_30_at0_20_at90", "history_aware", 730.0): "layered history-aware 730 d"}
    for (case, form, cutoff), label in sel.items():
        sub = mesh[(mesh["case"] == case) & (mesh["inversion"] == form)
                   & (mesh["cutoff_day"] == cutoff)].sort_values("n_elem")
        color, marker, ls = C_MESH[label]
        ax.plot(sub["n_elem"], sub["cv_effective_hat_m2_yr"], marker=marker, ls=ls,
                ms=5, color=color, label=label, zorder=3)
    ax.axhline(TRUTH_CV, color="#43931f", lw=1.2, ls=":", zorder=2,
               label="prescribed $c_v$ = 4")
    ax.set_yscale("log")
    ax.set_ylim(1.0, 40.0)
    ax.set_xticks([80, 160, 320])
    ax.set_xlabel("number of elements")
    ax.set_ylabel("effective $c_v$ (m$^2$/yr)")
    ax.set_title("(b) noiseless mesh dependence", loc="left")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), ncols=2,
              frameon=False, fontsize=11, handlelength=1.6, columnspacing=1.2,
              handletextpad=0.5)

    fig.subplots_adjust(left=0.12, right=0.97, top=0.955, bottom=0.225, hspace=0.95)
    for ext in ("png", "pdf"):
        fig.savefig(rc.FIGURES / f"v2_knownA_control_mesh_sensitivity.{ext}")
    print("saved", rc.FIGURES / "v2_knownA_control_mesh_sensitivity.png")


if __name__ == "__main__":
    main()
