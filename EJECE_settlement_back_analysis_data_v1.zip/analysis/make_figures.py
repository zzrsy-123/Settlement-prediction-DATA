"""Task 6: publication-size figures (6.3 in wide, all text >= 11 pt).

Every figure is labelled as post-review retrospective / fixed-scenario
diagnostics. Legends sit outside the axes; panels are separated to avoid
overlap. PDF + PNG preview per figure.
"""
from __future__ import annotations

import os

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mplconfig_k3_revision")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import revision_core as rc

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 11.0, "axes.titlesize": 11.0, "axes.labelsize": 11.0,
    "xtick.labelsize": 11.0, "ytick.labelsize": 11.0, "legend.fontsize": 11.0,
    "axes.linewidth": 0.9, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "pdf.fonttype": 42,
})

MODEL_STYLE = {
    "primary_only": ("#737373", "--", "primary only"),
    "log1p": ("#D27028", "-", "exp + log1p(dt/58)"),
    "sqrt": ("#397A56", "-", "exp + sqrt(1+dt/58)-1"),
    "linear": ("#3977A8", "-", "exp + linear(dt/58)"),
    "hyperbolic": ("#8B5A9F", "-.", "hyperbolic (saturating)"),
}
SIGMA_COLOR = {5.0: "#3977A8", 10.0: "#D27028", 20.0: "#737373", 3.0: "#3977A8", 6.0: "#D27028"}
ELL_LS = {0.0: ":", 30.0: "--", 90.0: "-", 120.0: "-"}


def save(fig, stem):
    rc.FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(rc.FIGURES / f"{stem}.pdf")
    fig.savefig(rc.FIGURES / f"{stem}.png", dpi=200)
    plt.close(fig)


def fig1_model_comparison():
    day, settlement, s0, _ = rc.load_ballina()
    pred = pd.read_csv(rc.RESULTS / "ballina_per_point_predictions.csv")
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 7.0),
                             gridspec_kw={"height_ratios": [1.1, 1.0], "hspace": 0.58})
    ax = axes[0]
    train_mask = (day > rc.T0_DAY) & (day <= 215)
    later_mask = day > 215
    ax.plot(day, settlement, "-", color="#1F4E79", lw=1.0, zorder=2)
    ax.plot(day[train_mask], settlement[train_mask], "o", color="#1F4E79", ms=5,
            label="calibration readings", zorder=4)
    ax.plot(day[later_mask], settlement[later_mask], "o", mfc="white", color="#1F4E79",
            ms=5, label="later observations", zorder=4)
    for model, (color, ls, label) in MODEL_STYLE.items():
        sub = pred[pred["model"] == model].sort_values("day")
        ax.plot(sub["day"], sub["prediction_m"], ls=ls, color=color, lw=1.3, label="_nolegend_", zorder=3)
    ax.axvline(215, color="#9A9A9A", lw=0.8, ls=":")
    ax.set(xlabel="Time (day)", ylabel="Surface settlement (m)", xlim=(50, 1000))
    ax.set_title("a  Ballina: calibration through day 215",
                 loc="left", fontsize=11.0)
    reading_handles, _ = ax.get_legend_handles_labels()
    ax2 = axes[1]
    for model, (color, ls, label) in MODEL_STYLE.items():
        sub = pred[(pred["model"] == model) & (pred["split"] == "later_holdout")].sort_values("day")
        err = (sub["prediction_m"] - sub["observed_m"]) * 1000.0
        ax2.plot(sub["day"], err, ls, color=color, lw=1.3, marker="o", ms=3.5, label=label)
    ax2.axhline(0.0, color="#1F4E79", lw=0.9)
    ax2.set(xlabel="Time (day)", ylabel="Prediction error (mm)", xlim=(215, 1000))
    ax2.set_title("b  Errors at the 11 later observations",
                  loc="left", fontsize=11.0)
    handles = [plt.Line2D([], [], color=v[0], ls=v[1], lw=1.3, marker="o", ms=3.5,
                          label=v[2]) for v in MODEL_STYLE.values()]
    fig.legend(handles=reading_handles + handles, loc="lower center", ncol=2,
               columnspacing=1.0, handlelength=2.2, borderaxespad=0.6)
    fig.subplots_adjust(left=0.15, right=0.96, top=0.94, bottom=0.25)
    save(fig, "fig1_task1_model_comparison")


def fig2_conditional_profiles():
    prof = pd.read_csv(rc.RESULTS / "conditional_profiles.csv")
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 7.2))
    axes[0].set_position([0.14, 0.67, 0.81, 0.27])
    axes[1].set_position([0.14, 0.23, 0.81, 0.23])
    ax = axes[0]
    sub = prof[prof["case"] == "ballina"]
    for (sigma, ell), grp in sub.groupby(["sigma_mm", "ell_day"]):
        ax.plot(grp["k_day_inverse"], grp["delta_chi2"],
                color=SIGMA_COLOR[sigma], ls=ELL_LS[ell], lw=1.2,
                label=f"{sigma:g} mm, {ell:g} d")
    ax.axhline(3.841, color="black", lw=1.0)
    ax.set(xscale="log", xlabel="Rate k (1/day)", ylabel=r"$\Delta\chi^2$ (profile)",
           ylim=(0, 25))
    ax.set_title("a  Ballina, exp+log1p", loc="left", fontsize=11.0)
    handles = [plt.Line2D([], [], color=SIGMA_COLOR[s], label=rf"$\sigma={s:g}$ mm")
               for s in (5.0, 10.0, 20.0)]
    handles += [plt.Line2D([], [], color="#333333", ls=ELL_LS[e], label=rf"$\ell={e:g}$ d")
                for e in (0.0, 30.0, 90.0)]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.31),
              ncol=3, columnspacing=1.0, borderaxespad=0.0)
    ax2 = axes[1]
    sub = prof[prof["case"] == "haarajoki_natural_centreline"]
    for (sigma, ell), grp in sub.groupby(["sigma_mm", "ell_day"]):
        ax2.plot(grp["k_day_inverse"], grp["delta_chi2"],
                 color=SIGMA_COLOR[sigma], ls=ELL_LS[ell], lw=1.2,
                 label=f"{sigma:g} mm, {ell:g} d")
    ax2.axhline(3.841, color="black", lw=1.0)
    ax2.set(xscale="log", xlabel=r"Rate $c_v/H_{dr}^2$ (1/day)", ylabel=r"$\Delta\chi^2$ (profile)",
            ylim=(0, 25))
    ax2.set_title("b  Haarajoki natural, centreline", loc="left", fontsize=11.0)
    handles = [plt.Line2D([], [], color=SIGMA_COLOR[s], label=rf"$\sigma={s:g}$ mm")
               for s in (3.0, 6.0)]
    handles += [plt.Line2D([], [], color="#333333", ls=ELL_LS[e], label=rf"$\ell={e:g}$ d")
                for e in (0.0, 120.0)]
    ax2.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.43),
               ncol=2, columnspacing=1.3, borderaxespad=0.0)
    save(fig, "fig2_task2_conditional_profiles")


def fig3_joint_contour():
    grid = pd.read_csv(rc.RESULTS / "joint_objective_grid.csv")
    k = np.sort(grid["k_day_inverse"].unique())
    a = np.sort(grid["amplitude_primary_m"].unique())
    z = grid.pivot(index="amplitude_primary_m", columns="k_day_inverse", values="delta_chi2").to_numpy()
    fig, ax = plt.subplots(figsize=(6.3, 5.0))
    zc = np.clip(z, 0, 40)
    mesh = ax.pcolormesh(k, a, zc, cmap="viridis", shading="auto", rasterized=True)
    ax.contour(k, a, z, levels=[5.991], colors="white", linewidths=1.5)
    ax.contour(k, a, z, levels=[3.841], colors="white", linewidths=1.0, linestyles="dashed")
    i = np.unravel_index(np.argmin(z), z.shape)
    ax.plot(k[i[1]], a[i[0]], "o", ms=7, mfc="white", mec="#D27028", mew=1.6)
    ax.set(xscale="log", yscale="log", xlabel="Rate k (1/day)",
           ylabel="Primary amplitude (m)")
    ax.set_title("Ballina rate-amplitude objective",
                 loc="left", fontsize=11.0)
    handles = [
        plt.Line2D([], [], color="#555555", lw=1.5, label=r"$\Delta\chi^2$=5.991 (two-parameter reference)"),
        plt.Line2D([], [], color="#555555", lw=1.0, ls="--", label=r"$\Delta\chi^2$=3.841 (objective level)"),
        plt.Line2D([], [], marker="o", ls="", mfc="white", mec="#D27028", mew=1.6, ms=7,
                   label="grid minimum"),
    ]
    fig.legend(handles=handles, loc="lower center", fontsize=11.0, frameon=False)
    cb = fig.colorbar(mesh, ax=ax, pad=0.02)
    cb.set_label(r"$\Delta\chi^2$ (clipped at 40)", fontsize=11.0)
    cb.ax.tick_params(labelsize=11.0)
    fig.subplots_adjust(left=0.12, right=0.88, top=0.92, bottom=0.29)
    save(fig, "fig3_task3_joint_contour")


def fig4_synthetic():
    all_runs = pd.read_csv(rc.RESULTS / "synthetic_discrepancy_realizations.csv")
    df = all_runs[all_runs["realization"] > 0]
    order = ["matched", "de_plus20", "de_minus20", "boundary_truth_single",
             "boundary_truth_double", "omitted_secondary", "delayed_loading"]
    labels = ["matched", "$H_d$\n+20%", "$H_d$\n-20%", "true S\nfit D", "true D\nfit S",
              "omit\nsecondary", "delay\n2nd load"]
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 6.3), gridspec_kw={"hspace": 0.60})
    reference = all_runs[all_runs["noise_free"]].set_index("setting")
    for x, setting in enumerate(order[:5], start=1):
        ratio = float(reference.loc[setting, "cv_ratio_hat_over_true"])
        axes[0].plot(x, ratio, "o", color="#397A56", ms=6)
        below = setting == "de_minus20"
        axes[0].annotate(f"{ratio:g}", (x, ratio), xytext=(0, -8 if below else 6),
                         textcoords="offset points", ha="center", va="top" if below else "bottom")
    axes[0].text(6.5, 0.65, "Unresolved rates", ha="center", va="center", color="#737373")
    axes[0].set_xticks(range(1, 8), labels)
    axes[0].set_xlim(0.5, 7.5)
    axes[0].axhline(1.0, color="#1F4E79", lw=1.0)
    axes[0].set(yscale="log", ylim=(0.15, 7.0), ylabel=r"$\hat{c}_v / c_{v,true}$")
    axes[0].set_yticks([0.25, 0.5, 1, 2, 4], ["0.25", "0.5", "1", "2", "4"])
    axes[0].yaxis.set_minor_formatter(plt.NullFormatter())
    axes[0].set_title("a  Noise-free geometry mapping",
                      loc="left", fontsize=11.0)
    data2 = [df[df["setting"] == s]["late_rmse_m"].to_numpy() * 1000.0 for s in order]
    bp2 = axes[1].boxplot(data2, tick_labels=labels, whis=(5, 95),
                          flierprops={"markersize": 2.5})
    for med in bp2["medians"]:
        med.set_color("#D27028")
    axes[1].set(ylabel="Late-response RMSE (mm)")
    axes[1].set_title("b  Later-settlement error: 29 noisy realizations",
                      loc="left", fontsize=11.0)
    fig.subplots_adjust(left=0.15, right=0.96, top=0.95, bottom=0.15)
    save(fig, "fig4_task4_synthetic_discrepancy")


def fig5_propagation():
    df = pd.read_csv(rc.RESULTS / "input_propagation_samples.csv")
    forms = ["log1p", "sqrt", "linear"]
    scen = [(s, e) for s in (5.0, 10.0, 20.0) for e in (0.0, 30.0, 90.0)]
    colors = {"log1p": "#D27028", "sqrt": "#397A56", "linear": "#3977A8"}
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 6.5), gridspec_kw={"hspace": 0.60})
    width = 0.26
    for fi, form in enumerate(forms):
        for si, (s, e) in enumerate(scen):
            sub = df[(df["model"] == form) & (df["sigma_mm"] == s) & (df["ell_day"] == e)]
            x = si + (fi - 1) * width
            q05, q95 = sub["forecast_day974_m"].quantile([0.05, 0.95])
            med = sub["forecast_day974_m"].median()
            axes[0].plot([x, x], [q05, q95], color=colors[form], lw=2.4, solid_capstyle="butt")
            axes[0].plot(x, med, "o", color=colors[form], ms=4)
    axes[0].axhline(1.427, color="#1F4E79", lw=1.1)
    axes[0].set_xticks(range(len(scen)))
    axes[0].set_xticklabels([f"{s:g}/{e:g}" for s, e in scen], fontsize=11.0, rotation=45)
    axes[0].set(ylabel="974 d forecast (m)", xlabel="scenario sigma (mm) / ell (d)")
    axes[0].set_title("a  Day-974 settlement: conditional 5-95% spread",
                      loc="left", fontsize=11.0)
    for fi, form in enumerate(forms):
        for si, (s, e) in enumerate(scen):
            sub = df[(df["model"] == form) & (df["sigma_mm"] == s) & (df["ell_day"] == e)]
            x = si + (fi - 1) * width
            q05, q95 = sub["cr_eq_m2_year"].quantile([0.05, 0.95])
            med = sub["cr_eq_m2_year"].median()
            axes[1].plot([x, x], [q05, q95], color=colors[form], lw=2.4, solid_capstyle="butt")
            axes[1].plot(x, med, "o", color=colors[form], ms=4)
    axes[1].set_xticks(range(len(scen)))
    axes[1].set_xticklabels([f"{s:g}/{e:g}" for s, e in scen], fontsize=11.0, rotation=45)
    axes[1].set(ylabel=r"$c_{r,eq}$ (m$^2$/yr)", xlabel="scenario sigma (mm) / ell (d)",
                yscale="log")
    axes[1].set_title("b  Radial coefficient: cell diameter varied by +/-10%",
                      loc="left", fontsize=11.0)
    handles = [plt.Line2D([], [], color=colors[f], lw=2.4,
                          label={"log1p": "exp + log1p", "sqrt": "exp + sqrt", "linear": "exp + linear"}[f])
               for f in forms]
    handles.append(plt.Line2D([], [], color="#1F4E79", lw=1.1, label="observed: 1.427 m"))
    fig.legend(handles=handles, loc="lower center", ncol=2)
    fig.subplots_adjust(left=0.12, right=0.97, top=0.96, bottom=0.22)
    save(fig, "fig5_task5_propagation")


def main():
    fig1_model_comparison()
    fig2_conditional_profiles()
    fig3_joint_contour()
    fig4_synthetic()
    fig5_propagation()
    print("figures written to", rc.FIGURES)


if __name__ == "__main__":
    main()
