# Checks before making this repository public

1. All authors must confirm the files, author list, funding, and the MIT/CC BY 4.0 licence choices before the repository becomes public. Do not assign the authors' licence to underlying third-party publications or measurements.
2. Confirm that redistribution of the transcribed/digitized numerical values from Ballina, Haarajoki, Wu, and Liu is allowed under source terms. The original third-party workbook, PDFs, GIFs, and figure images are excluded. If any numerical table cannot be redistributed, remove it and document a direct source-access route instead.
3. Deposit an immutable release in a recognized repository that assigns a DOI or another persistent identifier. For double-anonymous review, use a repository review link that hides author metadata when available.
4. Update the manuscript's Data Availability statement and dataset citation with the actual URL/DOI. No identifier is invented in this package.
5. Verify the final repository file list against `FILE_INDEX.csv`, then review the release on a different machine/account before final journal submission.
