# Data licence

Copyright 2026 Ziyang Zhang, Erxuan Cai, Jing Li, Minjie Wen, and Yiming Zhang.

The authors' original numerical results, synthetic data, derived tables, digitization annotations, metadata, and documentation in this release are licensed under [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/), to the extent that the authors hold rights in them. Please cite this release and the source publications listed in `README.md`.

This licence does not cover any underlying third-party observations, published papers, figures, source workbooks, or source images. Those materials remain subject to their owners' terms. Source PDFs, GIFs, and the publisher-provided workbook are not included here. The tables transcribed or digitized from those sources carry provenance and must not be represented as independently collected field measurements.
