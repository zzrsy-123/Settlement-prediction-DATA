# Haarajoki monitoring data provenance

## Source files

- `timese1_natural_section.gif`: official time--settlement graph for the natural-ground section.
- `timese2_pvd_section.gif`: official time--settlement graph for the PVD section.
- `haarajoki_final_report_2001.pdf`: final competition report retained under `06_source_checks_rendered_qc/source_checks/haarajoki_official`.

The graph files were downloaded from the Finnish Road Administration Haarajoki archive:

- Archive: https://www.tieh.fi/pailas/pailase.htm
- Time--settlement page: https://www.tieh.fi/pailas/timeset.htm
- Final report record: https://www.doria.fi/handle/10024/139029

The archive states that the original competition used the first 24 months of observations. Later monitoring data were published through October 2002. This study therefore fixes the first 24 months as the calibration period and reserves every later point as a temporal holdout.

## Digitization rule

The three plotted settlement gauges are the centreline and the gauges 4 m to the left and right. Marker centres were read from the official GIF files. Pixel coordinates and the corresponding engineering values are saved in `haarajoki_digitized_all.csv`. Settlement uses the printed plot scales:

- natural section: 0--500 mm between pixel rows 44 and 342;
- PVD section: 0--850 mm between pixel rows 38 and 492.

Time uses piecewise-linear interpolation between the printed date ticks. The first post-construction marker is the analysis anchor. All model fits use settlement increments relative to that marker. The source images, digitization overlay, pixel coordinates, conversion settings, and frozen split are retained so that the derived data can be audited.

## Interpretation boundary

The source consists of published graph coordinates rather than instrument-export files. The main analysis therefore reports effective response rates. Conversions to consolidation coefficients depend on assumed drainage lengths or idealized drain geometry and are treated as secondary mappings.
