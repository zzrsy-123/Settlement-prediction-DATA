# Settlement-based consolidation back-analysis: data and code (v1)

Companion numerical data and post-review analysis code for *Assessing Parameter Stability in Settlement-Based Consolidation Back-Analysis* (Ziyang Zhang, Erxuan Cai, Jing Li, Minjie Wen, and Yiming Zhang). This package is for public deposition; it is **not** a submission manuscript and contains no reviewer correspondence, internal QA logs, cached files, or downloaded source papers/images.

## Layout

- `data/ballina/`: monitoring observations and published forecast values transcribed from the public Fig. 3 and Fig. 10 spreadsheet accompanying Huang et al. (2021). `settlement_m` is metres; `vertical_pressure_kpa` is kPa; `day` is days. The original multi-sheet workbook is omitted.
- `data/haarajoki/`: our digitization of the Finnish Road Administration time-settlement graphs, with pixel coordinates and source/method notes. Settlement and increments are millimetres; elapsed time is days. The source graphs and report are omitted.
- `data/literature_curves/`: our plotted-curve digitizations for the Wu et al. (2023) and Liu et al. (2024) consistency checks. These are reconstructions of published curves, not independent observations.
- `data/supplementary_checks/`: compact numerical outputs for the implementation, published-curve, synthetic-repeatability, and Ballina sensitivity checks in Supporting Information S1-S3. The superseded Haarajoki v18 results are excluded.
- `analysis/results/`: current point-level predictions, realizations, profiles, summaries, and protocol JSON files supporting the main and supplementary figures/tables. All 32 current CSVs are retained; file names remove internal `task1`/`v2` prefixes.
- `analysis/*.py`: current Python calculations and plot builders, adapted only to read the two Ballina CSVs and the digitized Haarajoki CSV in this package. `analysis/METHODS_NOTES.md` records seeds, grids, units, and interpretation limits.
- `FILE_INDEX.csv`: per-file inventory, source mapping, role, size, and SHA-256 checksum.

## Reproduce current calculations

Python 3.12 and the libraries in `requirements.txt` are recommended. From the repository root, run:

```sh
python -m pip install -r requirements.txt
python analysis/run_task1_ballina_models.py
python analysis/run_task23_conditional_stats.py
python analysis/run_task4_synthetic_discrepancy.py
python analysis/run_task5_propagation.py
python analysis/v2_observational_baselines.py
python analysis/v2_fe_benchmark.py
python analysis/haarajoki_corrected.py
python analysis/make_figures.py
python analysis/v2_make_figure.py
python analysis/v2_make_si_figure.py
```

Some calculations are intentionally extensive (rate grids and repeated simulations). The supplied CSVs are the checked outputs. Numerical results are retrospective analyses and fixed-scenario diagnostics, not independent prospective validation. The old 60-term Haarajoki implementation was corrected; only the corrected output is included.

## Source provenance and reuse boundary

- Ballina source: Huang, S. et al. (2021), *Settlement Predictions of a Trial Embankment on Ballina Clay*, DOI [10.4417/IJGCH-06-04-07](https://doi.org/10.4417/IJGCH-06-04-07); public article/data page: https://geocasehistoriesjournal.org/issues/volume-6-4/settlement-predictions-of-a-trial-embankment-on-ballina-clay . The values here are limited to the two worksheets analyzed in this paper; consult and cite the source publication for original rights and context.
- Haarajoki source: Finnish Road Administration time-settlement archive https://www.tieh.fi/pailas/timeset.htm and Lojander & Vepsäläinen (2001), final report https://www.doria.fi/handle/10024/139029 . The CSVs are author-digitized coordinates, not instrument exports.
- Wu source: Wu et al. (2023), DOI [10.3390/app13063724](https://doi.org/10.3390/app13063724). Liu source: Liu et al. (2024), DOI [10.1007/s11440-024-02366-0](https://doi.org/10.1007/s11440-024-02366-0). Their digitized plots are within-study curve-reconstruction checks.
- Source PDFs, GIFs, the full Ballina workbook, and published figure images are not redistributed. The authors release their own code under MIT and their own derived tables/annotations under CC BY 4.0. No open licence is asserted over third-party source publications or underlying observations. See `PUBLICATION_REVIEW.md` before making this repository public.

## Data dictionary and missing values

The Ballina and Haarajoki input units are above; other column names include units (`_m`, `_mm`, `_day`, `_kpa`) where applicable. `analysis/METHODS_NOTES.md` documents the objective, fit/test splits, assumed errors, and parameter units. Blank/NaN fields in CSV outputs mean the corresponding model component or statistic is not applicable or could not be estimated; do not substitute zero. Inspect each CSV header and the manuscript/SI table caption when interpreting a result.

## Citation and repository identifier

Before release, add the final GitHub URL and, preferably, an archived version DOI from a recognized repository such as Zenodo. Cite the archived dataset in the manuscript and replace the manuscript's current “available upon reasonable request” statement with a dataset-to-location description. GitHub alone does not mint a durable dataset DOI.
